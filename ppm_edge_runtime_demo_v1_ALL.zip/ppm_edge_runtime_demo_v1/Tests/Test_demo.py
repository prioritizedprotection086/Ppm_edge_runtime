"""Tests for the demo/adapter layer (demo/*), not for the production
runtime itself (see Test_runtime.py / Test_import.py for that).

These confirm:
  - the demo engine's events exactly match what PPMRuntime.process()
    itself produces (differential check against the unmodified runtime)
  - the simulated AI recommender is clearly simulated, deterministic, and
    never mutates PPM-Edge's inputs on its own
  - the boundary-test vectors produce the documented behavior
  - the replay stream is exactly reproducible across independent runs and
    matches the checked-in golden fixture
  - every DemoEvent carries the minimum required fields from the V1 spec
"""
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))
sys.path.insert(0, str(REPO_ROOT))

from ppm_edge.runtime import PPMRuntime, InputSample, Priority

from demo.engine import DemoEngine
from demo.streams import replay_stream, boundary_stream, REPLAY_INITIAL_VALUE
from demo.oracle import verify_event
from demo.events import DemoEvent, REQUIRED_MINIMUM_FIELDS
from demo.recommender import SimulatedAIRecommender

FIXTURES_DIR = REPO_ROOT / "demo" / "fixtures"
REPLAY_GOLDEN_PATH = FIXTURES_DIR / "replay_golden.json"


# ---------------------------------------------------------------------
# Structural requirements
# ---------------------------------------------------------------------

def test_demo_event_has_minimum_required_fields():
    from dataclasses import fields
    present = {f.name for f in fields(DemoEvent)}
    assert REQUIRED_MINIMUM_FIELDS.issubset(present)


# ---------------------------------------------------------------------
# Differential: demo engine's PPM-Edge-facing output must exactly match
# calling PPMRuntime directly -- the adapter must not alter kernel results.
# ---------------------------------------------------------------------

def test_engine_matches_ppmruntime_directly():
    reference = PPMRuntime(initial_value=100)
    engine = DemoEngine(initial_value=100, ai_seed=1)

    samples = [
        (110, 20, Priority.NORMAL),
        (130, 20, Priority.NORMAL),
        (131, 20, Priority.HIGH),
        (131, 20, Priority.CRITICAL),
        (0, 0, Priority.LOW),
    ]
    for value, threshold, priority in samples:
        decision = reference.process(InputSample(value=value, threshold=threshold, priority=priority))
        event = engine.step("test", value, threshold, priority)

        assert event.delta == decision.delta
        assert event.protected == decision.protected
        assert event.confidence == decision.confidence
        assert event.new_last_value == decision.value
        assert event.priority == priority.name

    assert engine.final_state_tuple() == (
        reference.state.baseline,
        reference.state.last_value,
        reference.state.initialized,
        reference.state.protected,
        reference.state.confidence,
        int(reference.state.priority),
    )


def test_engine_never_mutates_ai_recommendation_inputs():
    """The engine must submit exactly the value/threshold/priority passed
    to step(), never something derived from the AI recommendation unless
    the caller explicitly used the AI's fields as the arguments."""
    engine = DemoEngine(initial_value=0, ai_seed=1)
    event = engine.step("test", value=42, threshold=5, priority=Priority.NORMAL)
    assert event.input_value == 42
    assert event.threshold == 5
    assert event.priority == "NORMAL"
    # AI recommendation is present but independent of the submitted values
    assert isinstance(event.ai_recommended_value, int)
    assert event.ai_recommended_priority in {"LOW", "NORMAL", "HIGH", "CRITICAL"}


# ---------------------------------------------------------------------
# Simulated AI recommender: deterministic given a seed, clearly simulated
# ---------------------------------------------------------------------

def test_recommender_is_seed_deterministic():
    r1 = SimulatedAIRecommender(seed=99)
    r2 = SimulatedAIRecommender(seed=99)
    for signal in (0, 100, -50, 12345):
        a = r1.recommend(signal)
        b = r2.recommend(signal)
        assert a == b


def test_recommender_confidence_in_expected_range():
    r = SimulatedAIRecommender(seed=3)
    for signal in range(20):
        reco = r.recommend(signal)
        assert 0.0 <= reco.ai_confidence <= 1.0


# ---------------------------------------------------------------------
# Boundary test vectors
# ---------------------------------------------------------------------

def test_boundary_zero_threshold_protects_any_nonzero_delta():
    engine = DemoEngine(initial_value=0, ai_seed=1)
    cases = {c.label: c for c in boundary_stream(initial_value=0)}
    c = cases["zero_threshold"]
    event = engine.step("boundary", c.value, c.threshold, c.priority, case_label=c.label)
    assert event.delta > 0
    assert event.protected is True
    assert verify_event(event) is None


def test_boundary_zero_delta_gives_full_confidence_but_still_protects_at_zero_threshold():
    """delta=0 gives full confidence (100), but at threshold=0 it is STILL
    `protected=True`, because the runtime's comparison is `delta >=
    threshold` and 0 >= 0 is true. This is the documented, correct
    behavior -- not a bug -- and is asserted explicitly here so it can't
    silently regress or be mis-described elsewhere in the demo."""
    engine = DemoEngine(initial_value=0, ai_seed=1)
    cases = {c.label: c for c in boundary_stream(initial_value=0)}
    engine.step("boundary", cases["zero_threshold"].value, cases["zero_threshold"].threshold, cases["zero_threshold"].priority)
    c = cases["zero_delta"]
    event = engine.step("boundary", c.value, c.threshold, c.priority, case_label=c.label)
    assert event.delta == 0
    assert event.confidence == 100
    assert event.protected is True  # delta(0) >= threshold(0)
    assert verify_event(event) is None


def test_boundary_negative_threshold_clamps_to_zero():
    """threshold<0 must behave exactly like threshold=0 (clamped)."""
    from ppm_edge.runtime import PPMRuntime as RefRuntime

    ref = RefRuntime(initial_value=0)
    d_zero = ref.process(InputSample(value=1, threshold=0, priority=Priority.NORMAL))

    ref2 = RefRuntime(initial_value=0)
    d_neg = ref2.process(InputSample(value=1, threshold=-50, priority=Priority.NORMAL))

    assert d_zero.protected == d_neg.protected == True  # noqa: E712
    assert d_zero.confidence == d_neg.confidence


def test_boundary_int32_extremes_and_critical_override():
    engine = DemoEngine(initial_value=0, ai_seed=1)
    mismatches = 0
    for case in boundary_stream(initial_value=0):
        event = engine.step("boundary", case.value, case.threshold, case.priority, case_label=case.label)
        if verify_event(event) is not None:
            mismatches += 1
        if case.label == "int32_max":
            assert event.new_last_value == 2147483647
        if case.label == "int32_min":
            assert event.new_last_value == -2147483648
            assert event.protected is True  # maximal delta must protect
        if case.label == "critical_override":
            assert event.priority == "CRITICAL"
            assert event.protected is True  # CRITICAL forces protection regardless of threshold
    assert mismatches == 0


def test_all_boundary_cases_pass_oracle():
    engine = DemoEngine(initial_value=0, ai_seed=5)
    for case in boundary_stream(initial_value=0):
        event = engine.step("boundary", case.value, case.threshold, case.priority, case_label=case.label)
        problem = verify_event(event)
        assert problem is None, f"case={case.label}: {problem}"


# ---------------------------------------------------------------------
# Replay: exact reproducibility
# ---------------------------------------------------------------------

def _run_replay():
    engine = DemoEngine(initial_value=REPLAY_INITIAL_VALUE, ai_seed=42)
    for value, threshold, priority in replay_stream():
        engine.step("replay", value, threshold, priority)
    return engine


def test_replay_two_independent_runs_produce_identical_output_and_state():
    a = _run_replay()
    b = _run_replay()
    assert [e.to_dict() for e in a.events] == [e.to_dict() for e in b.events]
    assert a.final_state_tuple() == b.final_state_tuple()


def test_replay_matches_golden_fixture():
    assert REPLAY_GOLDEN_PATH.exists(), "golden replay fixture is missing"
    golden = json.loads(REPLAY_GOLDEN_PATH.read_text())
    engine = _run_replay()
    produced = [e.to_dict() for e in engine.events]
    assert produced == golden["events"]
    assert engine.runtime.state.baseline == golden["final_state"]["baseline"]
    assert engine.runtime.state.last_value == golden["final_state"]["last_value"]
    assert engine.runtime.state.initialized == golden["final_state"]["initialized"]
    assert engine.runtime.state.protected == golden["final_state"]["protected"]
    assert engine.runtime.state.confidence == golden["final_state"]["confidence"]
    assert int(engine.runtime.state.priority) == golden["final_state"]["priority"]


def test_replay_all_events_pass_oracle():
    engine = _run_replay()
    for event in engine.events:
        assert verify_event(event) is None


# ---------------------------------------------------------------------
# Production files untouched (belt-and-suspenders sanity check)
# ---------------------------------------------------------------------

def test_production_runtime_module_unaffected_by_importing_demo():
    """Importing demo.* should not add attributes to or otherwise alter
    ppm_edge.runtime -- the adapter must be strictly additive."""
    import ppm_edge.runtime as rt_module
    expected_public = {"Priority", "InputSample", "Decision", "RuntimeState", "PPMRuntime"}
    actual_public = {name for name in dir(rt_module) if not name.startswith("_")}
    # demo module may already be imported by earlier tests in this file;
    # what matters is the production module's own public surface is exactly
    # what it declares, not that our import added anything to it.
    assert expected_public.issubset(actual_public)
