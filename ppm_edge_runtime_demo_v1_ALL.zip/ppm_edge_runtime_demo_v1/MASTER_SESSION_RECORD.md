# MASTER SESSION RECORD — PPM-Edge Runtime: Characterization, Decision, Demonstrator, Freeze

**Repository:** `Ppm_edge_runtime` (privacy-preserving deterministic adaptive
regulation runtime for wearables / edge AI)
**Session scope:** native/CPython-boundary benchmarking → engineering
decision → AI-to-Action demonstrator (V1) → freeze + evidence package
**Final state:** V1 demonstrator frozen at commit
`37145182805357a8cc372b3539a3ab7c05fa1f1e` (tag `v1-demo-freeze`)

This document is a chronological record of everything done in this
session, what was concluded at each stage, and where the actual
deliverables are. It is the index — the underlying reports, code, and
logs are the evidence.

---

## Timeline

| Phase | What happened | Key artifact(s) |
|---|---|---|
| 1 | Boundary/carry-over/allocation stress characterization (C kernel + CPython extension, long-lived processes) | `boundary_stress_report.md`, `.json`, `boundary_stress_artifacts.zip` |
| 2 | Rigorous isolated-C-only benchmark requested and **built** (RDTSC timing, CPU affinity, 10+ trial design) | `bench/c_bench/rigorous_isolated_bench.c` (compiled, **not executed** — see note below) |
| 3 | "Stop measuring" instruction received; engineering decision made from existing evidence | Decision memo (KEEP `process()`) — see below |
| 4 | V1 AI-to-Action demonstrator built: thin adapter layer, 3 modes, 4-panel display, tests | `ppm_edge_demo_full_repo.zip`, `ppm_edge_demo.bundle` |
| 5 | V1 frozen, re-verified from a clean `git clone`, evidence package produced | `DEMO_EVIDENCE.md`, `DEMO_SCRIPT.md`, verification logs |

---

## Phase 1 — Boundary, Carry-Over, and Memory-Footprint Stress

**Goal:** determinism, memory footprint, heap-allocation behavior, and
state carry-over under stress, from long-lived processes (no per-call
process spawning).

**Method:**
- Pure-C stress binary (`bench/c_bench/alloc_and_carryover_stress.c`):
  2,000,000 sequential `ppm_process()` calls per run, boundary-heavy input
  stream (forced `INT32_MIN`/`MAX`, zero deltas, threshold=0,
  threshold=`INT32_MAX`, negative thresholds, forced `CRITICAL` priority
  every 317th call), checked against an independently-written oracle.
- `LD_PRELOAD` `malloc`/`calloc`/`realloc`/`free` interposer
  (`bench/shim/count_malloc.c`) with checkpointed query/reset functions,
  used to directly count heap allocation calls in isolated windows.
- Python-side long-lived-process harness (`bench/boundary_stress_report.py`)
  exercising the CPython extension boundary the same way, plus a
  differential test against the pure-Python reference implementation.

**Key results (all in `boundary_stress_report.md` / `.json`):**
- **Zero heap allocations** after `ppm_init()`, confirmed across two
  independent 2,000,000-call runs, in every allocation category
  (malloc/calloc/realloc/free) — matches direct source inspection (no
  allocator calls anywhere in `Src/Ppm_edge.c`).
- **State size, measured, not estimated:** raw C struct `ppm_runtime_t` =
  20 bytes; CPython extension object = 40 bytes (state inline, no
  separate allocation); pure-Python dataclass = ~248 bytes true total once
  boxed `int`/`bool`/`IntEnum` fields are counted (a ~12x inflation over
  the raw struct — the boxing, not the container, is the cost).
- **Zero carry-over mismatches** across all four independent checks (C×2,
  CPython extension, differential vs. pure Python) against the
  independent oracle.
- **Deterministic replay confirmed:** same seeded stream, 3 independent
  runs, byte-identical output sequences and final state.
- Long-lived C-API latency: p50=199ns, p95=295ns, p99=361ns at the
  extension boundary vs. p50=22ns for the isolated C kernel — the
  Python↔C boundary is ~9x the raw kernel call.

Two methodology bugs were found and fixed *during* this phase and
disclosed rather than smoothed over: an unwarmed `clock_gettime()`
first-call artifact, and a harness buffer allocated inside instead of
before a counted allocation window.

**Deliverables:** `boundary_stress_report.md`, `boundary_stress_report.json`,
`boundary_stress_artifacts.zip` (shim source, C stress binary, Python
harness, built extension).

---

## Phase 2 — Rigorous Isolated-C-Only Benchmark (built, not run)

A follow-up request asked for a stricter, pure-C-only (no Python/ctypes)
benchmark: CPU affinity/pinning, warm-up, batch timing to avoid
`clock_gettime` per-call tax, ≥ several million calls, boundary-heavy and
normal streams, full percentile suite (p50/p95/p99/p99.9/p99.99/max/mean/
stdev), ≥10 independent trials reported individually, zero-allocation and
oracle re-verification, and explicit system-info capture (CPU model,
affinity, compiler, OS, frequency-scaling controllability).

**What was built:** `bench/c_bench/rigorous_isolated_bench.c` — a
self-forking/exec'ing single binary (driver mode launches fresh child
processes of itself per trial for genuine process isolation), using
`lfence`-serialized RDTSC/RDTSCP for per-call timing (calibrated per-trial
against two bounding `clock_gettime` calls, not per-call), plus a
separate "measurement overhead reference" trial to quantify the
instrumentation's own cost. It compiled cleanly (`gcc -O2 -march=native`,
zero errors).

**What was NOT done:** the binary was **not executed**. The very next
message in the session stated the characterization phase was complete and
explicitly instructed not to re-run benchmarks to reconfirm an already-
established conclusion. The binary exists as built, verified-to-compile
tooling for future use, but produced no results in this session — this is
recorded here so the artifact list isn't misread as containing rigorous-
benchmark output that doesn't exist.

System facts gathered in the process (relevant to *any* future run of this
binary): single logical CPU in this sandbox (`nproc`=1), Intel Xeon
@2.80GHz, `constant_tsc`/`nonstop_tsc`/`rdtscp` flags present (TSC safe to
use as a timing source), `cpufreq` sysfs **not exposed** in this
environment (frequency scaling cannot be inspected or controlled from
userspace here — disclosed as a limitation).

---

## Phase 3 — Engineering Decision: KEEP `process()`

With characterization complete, the question was posed directly: given
the established evidence (C kernel ~4.3–4.8 ns/decision at batch≥128,
zero heap allocation; CPython extension `process()` ~768 ns mean, ~976K
ops/s; pure Python ~3.08 µs mean, ~298K ops/s; `process_batch(1024)`
~7.5 ns/decision, ~107M ops/s, 1.65× the native-C floor), should the
product adopt batching?

**Decision: KEEP `process()`.** Reasoning, drawn from the repository's
own documented architecture (`Readme`) since no downstream product/
integration layer exists in this repo to inspect directly:

- The runtime is designed around a streaming, one-signal-at-a-time
  control loop feeding actuators/safety policy — there's no natural
  accumulation point without adding latency that works against the
  stated "ultra-low-latency" / "bounded adaptive regulation" goals.
- Adopting `process_batch()` at the product boundary would change latency
  semantics (a decision now waits for a batch to fill), not just
  implementation — not a drop-in swap.
- The ~1.65× batch-vs-native gap is real but not worth closing: closing
  it means optimizing the Python↔C marshalling boundary, work spent on a
  boundary that already does ~976K ops/s — several orders of magnitude
  past realistic wearable/edge sampling rates (Hz–low kHz).
- Practical cost of staying with `process()`: ~760 ns/decision absolute
  overhead vs. batched. At a demanding 1 kHz sampling rate, that's
  ~0.077% of one CPU core — invisible at the workload scale this runtime
  targets.

This decision was recorded conversationally in-session (no separate
decision-memo file was produced as a standalone artifact) and directly
shaped Phase 4: the demonstrator uses `process()` exclusively, and its
EVIDENCE panel states the KEEP decision explicitly.

---

## Phase 4 — V1 AI-to-Action Demonstrator

**Goal:** make the architecture "AI proposes → PPM-Edge evaluates →
deterministic decision → auditable event → exact replay" immediately
understandable, without touching production code.

**Constraint respected throughout:** `Src/Ppm_edge.c`, `Src/Ppm_edge.h`,
`src/ppm_edge/runtime.py`, `src/ppm_edge/__init__.py` never modified —
confirmed by `git diff` at every checkpoint (empty every time).

**What was built** — a thin `demo/` package, stdlib-only, no new
dependencies:

| File | Role |
|---|---|
| `demo/recommender.py` | `SimulatedAIRecommender` — seeded, deterministic, explicitly labeled SIMULATED everywhere |
| `demo/streams.py` | fixed `REPLAY_STREAM`, `boundary_stream()` (6 edge cases), `live_stream()` |
| `demo/engine.py` | `DemoEngine` — calls `PPMRuntime.process()` once per step, records result, never subclasses/monkey-patches it |
| `demo/events.py` | `DemoEvent` — structured/auditable record (all required fields: sequence, input_value, threshold, priority, previous_last_value, delta, protected, confidence, new_last_value) |
| `demo/oracle.py` | independent recomputation used only to *verify* the demo's own log |
| `demo/render.py` | plain-text 4-panel terminal rendering (SIGNAL / AI RECOMMENDATION / PPM-EDGE DECISION / EVIDENCE) |
| `demo/cli.py` | mode dispatch: `live` / `replay` / `boundary` |
| `demo/evidence.py` | static reference to Phase 1 benchmark numbers (not re-measured) |
| `demo/fixtures/replay_golden.json` | checked-in golden replay output, generated by actually running the engine |
| `run_demo.py` | one-command launcher |
| `run_tests.py` | zero-dependency test runner (no `pytest`/network in this sandbox) |
| `Tests/Test_demo.py` | 14 new adapter-layer tests |

**Design choice made explicit (and documented):** in `live` mode, the
AI's recommended value/priority genuinely drive what's submitted to
PPM-Edge (`threshold` stays an externally configured parameter, not
AI-proposed). In `replay`/`boundary`, PPM-Edge inputs come from fixed
checked-in vectors instead of the AI recommender, because reproducibility
and precise edge-case coverage need known-in-advance values.

**Result at this stage:** 30/30 tests passing (16 pre-existing + 14 new),
all three modes verified working, git diff on production files empty.

**Deliverables (this phase):** `ppm_edge_ai_to_action_demo.zip`,
`demo_README.md`, `GIT_DIFF_vs_baseline.txt` — **superseded by Phase 5's
corrected versions**, see note below.

---

## Phase 5 — Freeze, Correction, and Evidence Package

**Instruction:** freeze V1 (no further optimization/redesign), turn it
into a credible research artifact: exact commit hash, clean production
diff, full test suite from a *clean* environment, all three modes
re-verified from the documented README commands, a concise
`DEMO_EVIDENCE.md`, and a 90-second recording script.

**Correction made during evidence capture (documentation fix, not a
behavior change):** while extracting per-case boundary results for the
evidence table, the `zero_delta` boundary case's inline label and its
test name were found to incorrectly state "not protected." Actual (and
correct) runtime behavior is `protected=True` for that case, because the
comparison is `delta >= threshold` and `0 >= 0` is true — a zero
threshold protects even a zero delta. This was fixed in
`demo/streams.py`'s case description and the test name/assertion in
`Tests/Test_demo.py`, as its own git commit, with **no change to any
decision logic**. This means the Phase-4 artifacts (`ppm_edge_ai_to_action_demo.zip`,
`GIT_DIFF_vs_baseline.txt`, `demo_README.md`) reflect the *pre-correction*
state and were superseded — the files listed under "Final deliverables"
below are the corrected, re-verified versions and are what should be
used.

**Verification method:** `git clone` into a **fresh directory** (not the
working directory), `git checkout v1-demo-freeze`, confirmed clean
working tree and no stale `__pycache__`, then every command run from that
fresh checkout.

**Commit / tag:**

| | |
|---|---|
| Frozen commit | `37145182805357a8cc372b3539a3ab7c05fa1f1e` |
| Tag | `v1-demo-freeze` |
| Baseline (pristine upload) | `235ab5f636b3868fa7bb92987ec74647969ae5ed` |
| Diff, baseline → freeze | 14 files added, 1,339 insertions, **0 modifications** to any pre-existing file |

**Environment this was verified in:** Python 3.12.3, gcc 13.3.0 (Ubuntu
13.3.0-6ubuntu2~24.04.1), Linux 6.18.5-fc-v20 x86_64, Intel Xeon
@2.80GHz (1 logical CPU, virtualized sandbox), git 2.43.0.

**Results, from the clean checkout:**
- `python3 run_tests.py` → **30/30 passed, exit 0**.
- `python3 run_demo.py --mode replay --quiet` → `MATCH` (two independent
  in-process runs identical, matches checked-in golden fixture), 0
  mismatches, exit 0.
- `python3 run_demo.py --mode boundary` → 6/6 cases, 0 mismatches, exit 0
  (including the corrected `zero_delta` case now showing `protected=True`
  accurately).
- `python3 run_demo.py --mode live` → 0 mismatches, exit 0.
- `git diff` on the four production files, baseline vs. freeze → **empty**.

**Explicit framing maintained throughout:** *"a deterministic, auditable
decision boundary demonstrator"* — no claims of AI safety, alignment,
security, or real-world protection anywhere in the demo, its README, or
its evidence docs.

---

## Final deliverables (use these, not the Phase-4 pre-correction versions)

| File | Contents |
|---|---|
| `DEMO_EVIDENCE.md` | What it proves / doesn't prove, architecture, 30/30 result, replay result, all 6 boundary cases in a table, production-file integrity, known limitations |
| `DEMO_SCRIPT.md` | 90-second recording script: exact commands, what the viewer should notice, timing |
| `ppm_edge_demo_full_repo.zip` | Full repo at the frozen commit (working-tree snapshot) |
| `ppm_edge_demo.bundle` | Clonable git bundle — `git clone ppm_edge_demo.bundle` reproduces the full history including the `v1-demo-freeze` tag |
| `production_file_diff_result.txt` | Raw `git diff` output proving production-file integrity |
| `test_run_log.txt` | Raw `python3 run_tests.py` output, clean checkout, 30/30 |
| `mode_verification_log.txt` | Raw output of all three modes run from the clean checkout |
| `boundary_stress_report.md` / `.json`, `boundary_stress_artifacts.zip` | Phase 1 characterization evidence (kernel-level, pre-demo) |

## What was explicitly NOT done in this session

- The rigorous isolated-C-only benchmark (Phase 2) was built but never
  executed — no results from it exist.
- No further optimization or redesign was applied to V1 after the freeze
  instruction — the one change made (Phase 5) was a documentation/label
  correction with an accompanying test-name fix, not a logic or algorithm
  change, and is disclosed as such in `DEMO_EVIDENCE.md`.
- No claims of AI safety, alignment, security, or real-world protection
  were made about the AI recommendation layer (which is explicitly a
  seeded random stand-in) or about the demonstrator as a whole.
