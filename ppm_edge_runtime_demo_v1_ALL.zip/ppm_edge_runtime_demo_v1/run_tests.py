#!/usr/bin/env python3
"""Zero-dependency test runner.

Use `pytest` directly if it's available in your environment -- this
repository's test files (Tests/Test_*.py) are ordinary pytest-style
`assert`-based test functions and pytest.ini already points at them.

This script exists only for environments without network access to
install pytest (e.g. this sandbox). It discovers the same Tests/Test_*.py
files, imports each, runs every top-level `test_*` function, and reports
pass/fail -- same discovery convention, same assertions, no pytest
dependency required.

Usage:
    python3 run_tests.py
"""
import importlib.util
import sys
import traceback
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
TESTS_DIR = REPO_ROOT / "Tests"


def discover_test_files():
    return sorted(TESTS_DIR.glob("Test_*.py")) + sorted(TESTS_DIR.glob("test_*.py"))


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    sys.path.insert(0, str(REPO_ROOT / "src"))
    sys.path.insert(0, str(REPO_ROOT))

    files = discover_test_files()
    if not files:
        print(f"No test files found under {TESTS_DIR}")
        return 1

    total = 0
    failed = 0
    failures = []

    for path in files:
        print(f"\n{path.relative_to(REPO_ROOT)}")
        try:
            module = load_module(path)
        except Exception:  # noqa: BLE001
            print(f"  MODULE IMPORT ERROR")
            traceback.print_exc()
            failed += 1
            total += 1
            continue

        test_funcs = [
            getattr(module, name)
            for name in dir(module)
            if name.startswith("test_") and callable(getattr(module, name))
        ]
        for fn in test_funcs:
            total += 1
            try:
                fn()
                print(f"  PASS  {fn.__name__}")
            except Exception as e:  # noqa: BLE001
                failed += 1
                print(f"  FAIL  {fn.__name__}: {type(e).__name__}: {e}")
                failures.append((path.name, fn.__name__, traceback.format_exc()))

    print(f"\n{'=' * 60}")
    print(f"{total - failed}/{total} passed")
    if failures:
        print(f"\n{failed} FAILURE(S):")
        for filename, name, tb in failures:
            print(f"\n--- {filename}::{name} ---")
            print(tb)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
