"""PPM-Edge AI-to-Action demonstrator CLI.

    AI proposes -> PPM-Edge evaluates -> deterministic decision ->
    auditable event -> exact replay

Three modes:
  live      One simulated signal at a time through PPMRuntime.process(),
            preserving real-time (no batching) semantics. The AI
            recommendation's value/priority is what actually gets
            submitted; threshold is an externally configured safety
            parameter, not something the AI proposes.
  replay    Feeds the fixed, checked-in REPLAY_STREAM and verifies the
            output sequence and final state exactly reproduce a checked-in
            golden fixture, and independently reproduce each other across
            two fresh runs in this same process.
  boundary  Deliberately exercises threshold=0, threshold<0, INT32_MIN,
            INT32_MAX, delta=0, and CRITICAL priority, verifying every
            case against an independent oracle.
"""
import argparse
import json
import sys
import time
from pathlib import Path

from ppm_edge.runtime import Priority

from .engine import DemoEngine
from .streams import replay_stream, boundary_stream, live_stream, REPLAY_INITIAL_VALUE
from .oracle import verify_event
from .render import render_event, render_evidence_summary
from .evidence import PRIOR_BENCHMARK_EVIDENCE

FIXTURES_DIR = Path(__file__).parent / "fixtures"
REPLAY_GOLDEN_PATH = FIXTURES_DIR / "replay_golden.json"


def run_live(args) -> int:
    print(f"LIVE mode: {args.count} simulated real-time signals through process() one at a time.\n")
    engine = DemoEngine(initial_value=args.initial_value, ai_seed=args.seed)
    thresholds = live_stream(seed=args.seed, start=args.initial_value)

    mismatches = 0
    for _ in range(args.count):
        previous_last_value = engine.runtime.state.last_value
        ai_reco = engine.recommender.recommend(previous_last_value)
        threshold = next(thresholds)

        event = engine.step(
            "live",
            value=ai_reco.recommended_value,
            threshold=threshold,
            priority=ai_reco.recommended_priority,
            ai_reco=ai_reco,
        )
        problem = verify_event(event)
        if problem:
            mismatches += 1
            print(f"  !! oracle mismatch on event #{event.sequence}: {problem}")

        if not args.quiet:
            print(render_event(event))
        if args.delay > 0:
            time.sleep(args.delay)

    print()
    print(
        render_evidence_summary(
            mode="live",
            event_count=len(engine.events),
            mismatches=mismatches,
            replay_status="N/A (live mode is seed-deterministic like replay, but isn't checked against a golden fixture here -- see replay mode for that evidence)",
            prior_evidence=PRIOR_BENCHMARK_EVIDENCE,
        )
    )
    return 0 if mismatches == 0 else 1


def run_replay(args) -> int:
    print("REPLAY mode: fixed deterministic stream through process(), verified against a checked-in golden fixture.\n")

    def run_once():
        engine = DemoEngine(initial_value=REPLAY_INITIAL_VALUE, ai_seed=42)
        for value, threshold, priority in replay_stream():
            engine.step("replay", value, threshold, priority)
        return engine

    engine_a = run_once()
    engine_b = run_once()

    mismatches = 0
    for event in engine_a.events:
        problem = verify_event(event)
        if problem:
            mismatches += 1
            print(f"  !! oracle mismatch on event #{event.sequence}: {problem}")
        if not args.quiet:
            print(render_event(event))

    events_a = [e.to_dict() for e in engine_a.events]
    events_b = [e.to_dict() for e in engine_b.events]
    two_runs_match = events_a == events_b and engine_a.final_state_tuple() == engine_b.final_state_tuple()

    golden_match = None
    if REPLAY_GOLDEN_PATH.exists():
        golden = json.loads(REPLAY_GOLDEN_PATH.read_text())
        golden_match = events_a == golden["events"]
        golden_final = (
            golden["final_state"]["baseline"],
            golden["final_state"]["last_value"],
            golden["final_state"]["initialized"],
            golden["final_state"]["protected"],
            golden["final_state"]["confidence"],
            golden["final_state"]["priority"],
        )
        golden_match = golden_match and (engine_a.final_state_tuple() == golden_final)

    if two_runs_match and (golden_match is not False):
        replay_status = "MATCH (two independent in-process runs identical"
        replay_status += "; matches checked-in golden fixture)" if golden_match else "; no golden fixture found)"
    else:
        replay_status = "MISMATCH -- see details above"
        mismatches += 1

    print()
    print(
        render_evidence_summary(
            mode="replay",
            event_count=len(engine_a.events),
            mismatches=mismatches,
            replay_status=replay_status,
            prior_evidence=PRIOR_BENCHMARK_EVIDENCE,
        )
    )
    return 0 if mismatches == 0 else 1


def run_boundary(args) -> int:
    print("BOUNDARY TEST mode: threshold=0, threshold<0, INT32_MIN, INT32_MAX, delta=0, CRITICAL priority.\n")
    engine = DemoEngine(initial_value=args.initial_value, ai_seed=args.seed)

    mismatches = 0
    for case in boundary_stream(initial_value=args.initial_value):
        event = engine.step(
            "boundary",
            value=case.value,
            threshold=case.threshold,
            priority=case.priority,
            case_label=case.label,
        )
        problem = verify_event(event)
        if problem:
            mismatches += 1
            print(f"  !! oracle mismatch on case '{case.label}': {problem}")

        if not args.quiet:
            print(render_event(event))
            print(f"  exercises: {case.what_it_exercises}")

    print()
    print(
        render_evidence_summary(
            mode="boundary",
            event_count=len(engine.events),
            mismatches=mismatches,
            replay_status="N/A (boundary mode; see replay mode for exact-reproduction evidence)",
            prior_evidence=PRIOR_BENCHMARK_EVIDENCE,
        )
    )
    return 0 if mismatches == 0 else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ppm-edge-demo",
        description="PPM-Edge AI-to-Action demonstrator: AI proposes -> PPM-Edge evaluates -> deterministic decision -> auditable event -> exact replay.",
    )
    parser.add_argument("--mode", choices=["live", "replay", "boundary"], required=True)
    parser.add_argument("--count", type=int, default=10, help="number of ticks in live mode (default: 10)")
    parser.add_argument("--delay", type=float, default=0.0, help="seconds between ticks in live mode (default: 0, no delay)")
    parser.add_argument("--seed", type=int, default=7, help="AI recommender / live-stream seed (default: 7)")
    parser.add_argument("--initial-value", type=int, default=500, help="starting baseline signal value (default: 500)")
    parser.add_argument("--quiet", action="store_true", help="suppress per-event panels, print only the evidence summary")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.mode == "live":
        return run_live(args)
    if args.mode == "replay":
        return run_replay(args)
    if args.mode == "boundary":
        return run_boundary(args)
    return 2  # pragma: no cover - argparse enforces choices


if __name__ == "__main__":
    sys.exit(main())
