# 90-Second Demo Recording Script

Framing line to say at the very start (on camera or as opening text):

> "This is a deterministic, auditable decision boundary demonstrator.
> It's not a claim of AI safety, alignment, or real-world protection —
> it's a working demonstration that a probabilistic recommendation and a
> deterministic decision are two different things, and you can make that
> boundary visible and replayable."

Terminal setup: repo root, font large enough to read on a recording,
nothing else running. All three commands below are exactly what's in
`demo/README.md` — nothing is faked or trimmed for the recording.

---

## 0:00–0:25 — LIVE

**Command:**
```
python3 run_demo.py --mode live --count 6 --delay 0.3
```

**What to say while it scrolls:**
"One signal at a time through `process()` — no batching, real-time
semantics. Every tick, the top panel is what the simulated AI proposed;
the bottom panel is what PPM-Edge actually decided."

**What the viewer should notice:**
- The `AI RECOMMENDATION` panel is explicitly labeled **`[SIMULATED —
  not a real model]`** — point at it, say it out loud once.
- The `AI RECOMMENDATION`'s `recommended_value` is literally what shows
  up as `input_value` in the `SIGNAL` panel above `PPM-EDGE DECISION` —
  the AI's proposal is what gets submitted, but `threshold` stays fixed,
  set outside the AI's control.
- `protected` flips `True`/`False` tick to tick, driven by `delta` vs.
  `threshold` — this is the deterministic part making its own call,
  independent of the AI's confidence number.

---

## 0:25–0:55 — BOUNDARY TEST

**Command:**
```
python3 run_demo.py --mode boundary
```

**What to say while it scrolls:**
"Six deliberate edge cases: zero threshold, negative threshold,
`INT32_MIN`, `INT32_MAX`, zero delta, and a `CRITICAL` priority override."

**What the viewer should notice (pause on each if recording allows):**
- **`zero_threshold`** — `protected=True` on a delta of just 1.
- **`zero_delta`** — same value resubmitted, `confidence=100`, but
  `protected` is *still* `True` — call this one out specifically, it's
  the least obvious case: `delta(0) >= threshold(0)` is true, so a zero
  threshold protects even a zero delta.
- **`int32_max` → `int32_min` back to back** — the delta is
  `4,294,967,295`, computed and handled cleanly, no crash, no overflow.
- **`critical_override`** — `threshold=2147483647` (as large as it gets)
  but `protected=True` anyway, because priority is `CRITICAL`. This is
  the clearest single frame for "the deterministic layer can override
  based on policy, not just magnitude."
- At the bottom: **`EVIDENCE` panel, `mismatches: 0`** — every case was
  checked against an independently-written oracle, not just eyeballed.

---

## 0:55–1:30 — REPLAY

**Command:**
```
python3 run_demo.py --mode replay --quiet
```

**What to say while it prints:**
"Same recorded stream, run twice, independently, in this same process —
and checked against a fixture that was generated once and committed to
the repo."

**What the viewer should notice:**
- The single line that matters: **`replay status: MATCH (two independent
  in-process runs identical; matches checked-in golden fixture)`**.
- `mismatches (independent oracle check): 0`.
- Close on this line: "Same input, same output, every time — that's the
  deterministic half of the boundary this demo is about."

---

## Closing line (optional, last 2–3 seconds)

> "Recommendation and decision, kept visibly separate, every step
> auditable, every replay exact. That's the whole claim."

---

## Notes for whoever records this

- Do not edit/cut mid-command output — the point is that what's on
  screen is exactly what running the documented command produces.
- If recording at normal speed feels rushed, `--delay 0.3` on LIVE can be
  raised to `0.5`–`0.6`; adjust `--count` down to compensate if the total
  needs to stay under ~30s for that segment.
- All three commands and their exit codes are verified in
  `demo/DEMO_EVIDENCE.md` from a clean `git clone` — if a re-recording
  ever shows different output, that's a real signal to investigate, not
  something to paper over in the recording.
