"""Reference to previously-established benchmark/correctness evidence.

These figures come from the earlier characterization work in this
repository's benchmark reports (bench/results/, and the prior native-
boundary/CPython-extension/rigorous-isolated-C reports). They are NOT
re-measured by this demo -- the characterization phase is complete, and
re-running multi-million-call benchmarks on every demo invocation would
be slow, pointless, and exactly the kind of "measure it again just to be
sure" this project has already moved past. This module only displays a
static summary for context in the EVIDENCE panel.
"""

PRIOR_BENCHMARK_EVIDENCE = {
    "c_kernel": {
        "latency": "~4.3-4.8 ns/decision at batch >= 128",
        "heap_allocation_after_init": "zero (verified with an LD_PRELOAD "
        "malloc/calloc/realloc/free interposer across multiple independent "
        "multi-million-call runs)",
    },
    "cpython_extension_process": {
        "mean_latency": "~768 ns/call",
        "throughput": "~976K ops/s",
    },
    "pure_python": {
        "mean_latency": "~3.08 us/call",
        "throughput": "~298K ops/s",
    },
    "cpython_extension_process_batch_1024": {
        "latency": "~7.5 ns/decision",
        "throughput": "~107M ops/s",
        "note": "~1.65x the native-C floor; not adopted at the product "
        "boundary -- see the KEEP decision memo, this demo uses process().",
    },
    "correctness": (
        "Determinism, state carry-over (millions of calls, boundary "
        "values, priority overrides), zero-allocation-after-init, and "
        "long-run stability were all independently exercised and passed "
        "in prior rounds; this demo re-checks a small, fast subset live "
        "(see replay_status / mismatches in this panel) rather than "
        "repeating the full characterization."
    ),
    "decision": "KEEP process() for the real-time path (see decision memo); "
    "process_batch() not adopted at the product boundary.",
}
