# PPM-Edge AI-to-Action Demonstrator (V1)

A thin integration layer around the existing, **unmodified** PPM-Edge
runtime. It exists to make one architectural boundary immediately visible:

```
AI proposes  -->  PPM-Edge evaluates  -->  deterministic decision  -->  auditable event  -->  exact replay
(probabilistic)      (deterministic)
```

The AI recommendation panel in this demo is **explicitly simulated** —
a seeded random stand-in, not a trained model. The demo does not claim the
AI's proposal is safe *because* PPM-Edge exists; it makes the boundary
between "AI proposes" and "deterministic system decides" visible and
auditable, on purpose.

## Run it

From the repository root, no build step, no extra dependencies (Python
standard library only):

```bash
python3 run_demo.py --mode live      # one signal at a time, real-time semantics
python3 run_demo.py --mode replay    # deterministic recorded stream, exact reproduction
python3 run_demo.py --mode boundary  # zero/negative threshold, INT32_MIN/MAX, zero delta, CRITICAL
```

Useful flags (see `python3 run_demo.py --help`):

- `--count N` — number of ticks in `live` mode (default 10)
- `--delay S` — seconds between ticks in `live` mode, for a slower feel (default 0)
- `--seed N` — seeds the simulated AI recommender / live stream (default 7)
- `--quiet` — print only the final EVIDENCE summary, skip per-event panels

## Run the tests

```bash
pytest                 # if pytest is available in your environment
python3 run_tests.py   # zero-dependency fallback (same Tests/Test_*.py files, no install needed)
```

`run_tests.py` exists only because this repository's sandbox has no
network access to `pip install pytest`. It discovers and runs the exact
same `Tests/Test_*.py` files pytest would, using the exact same `assert`
semantics — it's a fallback runner, not a parallel test suite.

## What's in the four panels

| Panel | Contents |
|---|---|
| **SIGNAL** | `input_value`, previous `last_value` |
| **AI RECOMMENDATION** | simulated `recommended_value`, `priority`, `ai_confidence` — clearly labeled SIMULATED |
| **PPM-EDGE DECISION** | `threshold`, submitted `priority`, `delta`, `protected`, `confidence`, `new_last_value` — all straight from `PPMRuntime.process()` |
| **EVIDENCE** | event count, oracle-verified mismatches this run, replay status, and a static summary of prior benchmark/correctness results (not re-measured here) |

Every processed event is recorded as a structured `DemoEvent` (see
`demo/events.py`) with at minimum: `sequence`, `input_value`, `threshold`,
`priority`, `previous_last_value`, `delta`, `protected`, `confidence`,
`new_last_value` — plus the AI-side fields, clearly prefixed `ai_` so it's
always obvious which numbers came from the simulated recommender and which
came from the deterministic kernel.

## Architecture (short version)

```
demo/recommender.py   SimulatedAIRecommender  -- seeded, deterministic, explicitly fake
demo/streams.py        REPLAY_STREAM (fixed) / boundary_stream() / live_stream()
demo/engine.py          DemoEngine  -- wraps ppm_edge.runtime.PPMRuntime, unmodified
demo/events.py          DemoEvent   -- structured, auditable record
demo/oracle.py          independent recomputation, used only to verify/audit events
demo/render.py          plain-text panel rendering (stdlib only)
demo/cli.py             mode dispatch: live / replay / boundary
run_demo.py             one-command launcher
```

`DemoEngine` calls `PPMRuntime.process()` exactly once per step and never
subclasses, monkey-patches, or reimplements any part of it. All state
carry-over, threshold clamping, protection logic, and confidence scoring
comes from the unmodified runtime; the demo layer only records what came
back.

**Mode-specific data flow, stated explicitly because it matters for
audit-ability:**

- **LIVE**: the AI recommendation's `value`/`priority` *are* what get
  submitted to PPM-Edge. `threshold` is an externally configured
  safety-policy parameter — the AI does not propose it. This is the mode
  that shows "AI proposes → PPM-Edge evaluates" end-to-end.
- **REPLAY** and **BOUNDARY TEST**: the PPM-Edge inputs come from fixed,
  checked-in vectors (`REPLAY_STREAM` / `boundary_stream()`), not from the
  AI recommender — reproducibility and precise edge-case coverage require
  exact, known-in-advance values. A simulated recommendation is still
  shown alongside for panel consistency, but it does not drive these two
  modes' PPM-Edge inputs.

## 90-second demo script

1. **(0:00–0:25) LIVE** — `python3 run_demo.py --mode live --count 6 --delay 0.3`
   Point at the four panels scrolling by: AI proposes a value/priority each
   tick, PPM-Edge evaluates it against a fixed threshold and decides
   `protected` True/False with a `confidence` score, one signal at a time,
   no batching. Call out that the AI panel is explicitly labeled SIMULATED.

2. **(0:25–0:55) BOUNDARY TEST** — `python3 run_demo.py --mode boundary`
   Walk through the six panels: `zero_threshold` (any nonzero delta must
   protect), `zero_delta` (confidence jumps to 100), `negative_threshold`
   (clamps to 0, identical result to `zero_threshold`), `int32_max` /
   `int32_min` back-to-back (maximal representable delta, no overflow/crash),
   `critical_override` (CRITICAL priority forces protection even against a
   threshold of `INT32_MAX`). Point at `mismatches: 0` in the EVIDENCE panel.

3. **(0:55–1:30) REPLAY** — `python3 run_demo.py --mode replay --quiet`
   Show the EVIDENCE panel: `replay status: MATCH` — two independent
   in-process runs produced byte-identical output sequences and final
   state, and both match a checked-in golden fixture. This is the "exact
   replay" half of the architecture: given the same recorded stream, the
   deterministic decision layer reproduces itself exactly, every time.

## What this demo is not

- Not a claim that the simulated AI recommender is realistic, safe, or
  representative of any real model.
- Not a redesign or reimplementation of the PPM-Edge algorithm — the
  independent oracle in `demo/oracle.py` exists only to *verify* the
  demo's own event log, not to make any real decision.
- Not a performance benchmark. Timing/throughput numbers shown in the
  EVIDENCE panel are static references to prior characterization work in
  this repository (`bench/results/`), not re-measured by this demo.
