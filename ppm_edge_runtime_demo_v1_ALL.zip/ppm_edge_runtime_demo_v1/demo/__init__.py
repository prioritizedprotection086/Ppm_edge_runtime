"""PPM-Edge AI-to-Action demonstrator.

A thin integration layer around the existing, unmodified PPM-Edge runtime
(`ppm_edge.runtime.PPMRuntime`). Nothing in this package changes the
production kernel or its Python reference implementation; it only wires a
simulated recommendation source, a deterministic event log, and a small
terminal renderer around the runtime exactly as characterized.
"""
