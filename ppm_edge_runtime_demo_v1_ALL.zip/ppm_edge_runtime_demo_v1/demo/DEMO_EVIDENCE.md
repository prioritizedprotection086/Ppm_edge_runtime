# DEMO_EVIDENCE.md — PPM-Edge AI-to-Action Demonstrator (V1, frozen)

**This is a deterministic, auditable decision boundary demonstrator.**
It is not a claim of AI safety, alignment, security, or real-world
protection. It shows one thing clearly: a probabilistic recommendation
and a deterministic, auditable decision are two different things, and the
boundary between them can be made visible and replayable.

## Commit / version

| | |
|---|---|
| Frozen commit | `37145182805357a8cc372b3539a3ab7c05fa1f1e` |
| Tag | `v1-demo-freeze` |
| Baseline commit (pristine uploaded repo, pre-demo) | `235ab5f636b3868fa7bb92987ec74647969ae5ed` |
| Diff, baseline → freeze | 14 files added, 1,339 insertions, **0 modifications** to any pre-existing file |

## Environment this evidence was captured in

| | |
|---|---|
| Python | 3.12.3 (`/usr/bin/python3`) |
| Compiler | gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0 |
| OS / kernel | Linux 6.18.5-fc-v20 x86_64 (Ubuntu 24.04-based) |
| CPU | Intel(R) Xeon(R) Processor @ 2.80GHz, 1 logical CPU (virtualized sandbox) |
| git | 2.43.0 |
| Verification method | `git clone` into a fresh directory, `git checkout v1-demo-freeze`, confirmed clean working tree (`git status --short` empty) and no stale `__pycache__`, then every command below run from that fresh checkout |

## What this demonstrator proves

- **The boundary is real and visible.** A recommendation (`AI RECOMMENDATION`
  panel, explicitly simulated) and a decision (`PPM-EDGE DECISION` panel,
  from the unmodified `PPMRuntime.process()`) are structurally separate at
  every step, and every step is recorded as an auditable event.
- **The deterministic layer is deterministic.** Given the same recorded
  input stream, the decision layer reproduces the exact same output
  sequence and final state, every time (REPLAY mode, see below).
- **State carry-over and threshold/priority logic behave correctly at
  the edges**, including cases that are easy to get wrong: a threshold of
  exactly zero, a negative threshold, `INT32_MIN`/`INT32_MAX` signal
  values, a zero delta, and a priority override (BOUNDARY TEST mode).
- **The production runtime was not touched to build this.** `Src/Ppm_edge.c`,
  `Src/Ppm_edge.h`, `src/ppm_edge/runtime.py`, and `src/ppm_edge/__init__.py`
  are byte-identical to the pristine baseline (verified by `git diff`, see
  below) — the demo is strictly additive.
- **The adapter layer doesn't silently change kernel behavior.** A
  differential test (`test_engine_matches_ppmruntime_directly`) confirms
  the demo engine's recorded output exactly matches calling
  `PPMRuntime.process()` directly, sample for sample.

## What this demonstrator does NOT prove

- It does **not** prove the simulated AI recommender is realistic,
  well-calibrated, or representative of any real model — it's a seeded
  random stand-in, labeled as such everywhere it appears.
- It does **not** prove the PPM-Edge decision logic is *correct* in any
  domain sense (i.e., that its thresholds/priorities are the *right*
  policy for a real wearable/actuator system) — only that the
  implementation is deterministic, auditable, and behaves as documented
  at the edges tested here.
- It does **not** constitute a safety, security, or alignment
  certification of anything. No adversarial testing, no fuzzing beyond
  the six documented boundary cases, no concurrency/threading exposure
  (the runtime and demo are both single-threaded), no hardware-in-the-loop
  testing, no real sensor or actuator involved.
- It does **not** re-measure performance. Every number in the EVIDENCE
  panel under "prior benchmark evidence" is a static reference to earlier
  characterization work in this repository, not something this demo run
  measured.
- Passing 30/30 tests and 6/6 boundary cases in this environment does not
  guarantee identical behavior on different hardware, compilers, Python
  versions, or under concurrent/multi-threaded use — none of which this
  V1 exercises.

## Architecture / data flow

```
        SIMULATED                    UNMODIFIED, PRODUCTION
     ┌─────────────┐             ┌───────────────────────────┐
     │   AI         │  proposes  │   PPM-Edge                │  decides
     │   RECOMMEND  │ ─────────► │   PPMRuntime.process()    │ ─────────►  DemoEvent
     │  (seeded,    │  value +   │   (deterministic kernel,  │  delta,        (auditable,
     │   fake)      │  priority  │    unmodified)            │  protected,     structured)
     └─────────────┘             └───────────────────────────┘  confidence
```

- `demo/recommender.py` — `SimulatedAIRecommender`, seeded, deterministic,
  labeled SIMULATED everywhere it surfaces.
- `demo/engine.py` — `DemoEngine`, calls `PPMRuntime.process()` exactly
  once per step; never subclasses, monkey-patches, or reimplements it.
- `demo/events.py` — `DemoEvent`, the structured/auditable record.
- `demo/oracle.py` — an independently-written recomputation used *only*
  to verify the demo's own event log; it makes no real decisions.
- `demo/streams.py` — `REPLAY_STREAM` (fixed vectors) and
  `boundary_stream()` (fixed edge cases) do **not** depend on the AI
  recommender, by design — reproducibility and precise edge-case coverage
  require known-in-advance values. `LIVE` mode is the one place the AI
  recommendation's value/priority actually drive what's submitted to
  PPM-Edge; `threshold` remains an externally configured parameter in all
  three modes, not something the AI proposes.

## Test result: 30/30

Command (from a fresh `git clone` + `git checkout v1-demo-freeze`):
```
python3 run_tests.py
```
Result: **30/30 passed, exit code 0.**

- 16 pre-existing tests (`Tests/Test_runtime.py`, `Tests/Test_import.py`) —
  unmodified, confirming the production runtime's own behavior is
  unaffected.
- 14 new adapter-layer tests (`Tests/Test_demo.py`) — differential
  equivalence against `PPMRuntime` directly, recommender determinism,
  all six boundary cases against the independent oracle, replay
  reproducibility, replay-vs-golden-fixture match, and minimum-field
  structural checks on `DemoEvent`.

(`pytest` is not installed and this sandbox has no network access to
install it; `run_tests.py` runs the identical `Tests/Test_*.py` files
with the same `assert`-based semantics pytest would use. Anyone with
`pytest` available can run `pytest` directly against the same files.)

## Replay result: MATCH

Command:
```
python3 run_demo.py --mode replay --quiet
```
Result: `replay status: MATCH (two independent in-process runs identical;
matches checked-in golden fixture)`, `mismatches: 0`, exit code 0.

Two independently-constructed runtimes fed the same 10-vector recorded
stream produce byte-identical output sequences and identical final state,
and both match `demo/fixtures/replay_golden.json`, generated once by
actually running the engine and checked into the repository.

## Boundary test result: 6/6, 0 mismatches

Command:
```
python3 run_demo.py --mode boundary
```

| # | case | delta | protected | confidence | what it shows |
|---|---|---:|---|---:|---|
| 1 | `zero_threshold` | 1 | **True** | 50 | threshold=0: any nonzero delta triggers protection |
| 2 | `zero_delta` | 0 | **True** | 100 | delta=0 at threshold=0 still protects — `delta(0) >= threshold(0)` is true; the comparison includes equality |
| 3 | `negative_threshold` | 1 | **True** | 50 | threshold=-50 clamps to 0 — identical result to case 1 |
| 4 | `int32_max` | 2,147,483,145 | **True** | 50 | signal at `INT32_MAX`, no overflow/crash |
| 5 | `int32_min` | 4,294,967,295 | **True** | 50 | signal at `INT32_MIN` immediately after `INT32_MAX` — maximal representable delta, handled correctly |
| 6 | `critical_override` | 1 | **True** | 75 | `CRITICAL` priority forces protection even against `threshold=INT32_MAX`, where delta alone would not trigger it |

`mismatches (independent oracle check): 0`, exit code 0.

*Correction made during evidence capture:* case 2's description originally
read "not protected" — that was wrong. The actual (and correct) behavior
is `protected=True`, because the runtime's comparison is `delta >=
threshold`, not `delta > threshold`, and `0 >= 0` is true. The label, the
test name, and this table now state the actual behavior. This is a
documentation fix, not a behavior change — see the git history for the
exact commit.

## Production-file integrity result

Command (from the fresh clone, comparing the frozen tag against the
pristine baseline commit):
```
git diff 235ab5f v1-demo-freeze -- Src/Ppm_edge.c Src/Ppm_edge.h \
  src/ppm_edge/runtime.py src/ppm_edge/__init__.py
```
**Output: empty.** All four production files are byte-identical to the
original upload. `Tests/Test_runtime.py`, `Tests/Test_import.py`,
`Examples/Basic.c`, `CMakeLists.txt`, `Project.toml`, `pytest.ini`, and
`Readme` are likewise unmodified. The only changes between baseline and
freeze are 14 new, additive files under `demo/`, `Tests/Test_demo.py`,
`run_demo.py`, and `run_tests.py`.

## Known limitations

- Single-threaded only; no concurrency testing of any kind.
- Six boundary cases were chosen deliberately (they match the V1 spec)
  but are not an exhaustive fuzz/property-based sweep of the input space
  — prior benchmark rounds (referenced, not reproduced, in the EVIDENCE
  panel) did run millions of randomized + boundary-heavy calls against
  the C kernel directly; this demo's own live verification is intentionally
  small and fast, not a repeat of that characterization.
- The simulated AI recommender's "confidence" and "priority" heuristics
  are arbitrary and were chosen for demo variety, not calibrated against
  anything.
- Sandbox environment has a single logical CPU and no exposed CPU-frequency
  control — not representative of a real embedded/wearable target, and no
  claim is made that it is.
- No pytest in this environment; correctness was verified with a
  bundled zero-dependency runner (`run_tests.py`) that executes the exact
  same test files pytest would.
- REPLAY's golden fixture was generated by running this same engine once
  and checking in the output — it is a regression fixture, not an
  independently-sourced ground truth.
