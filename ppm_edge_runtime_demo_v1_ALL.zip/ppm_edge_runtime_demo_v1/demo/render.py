"""Plain-text terminal rendering for the four demo panels.

Stdlib only -- no curses, no rich, no ncurses bindings. Deliberately
simple: this is a demonstrator, not a dashboard product.
"""
from .events import DemoEvent

WIDTH = 78


def _rule(char: str = "-") -> str:
    return char * WIDTH


def render_event(event: DemoEvent) -> str:
    lines = []
    lines.append("=" * WIDTH)
    label = f" #{event.sequence:<4d} mode={event.mode.upper()}"
    if event.case_label:
        label += f"  case={event.case_label}"
    lines.append(label)
    lines.append(_rule())

    lines.append("SIGNAL")
    lines.append(
        f"  input_value={event.input_value}   "
        f"(previous last_value={event.previous_last_value})"
    )
    lines.append(_rule())

    lines.append("AI RECOMMENDATION  [SIMULATED -- not a real model]")
    lines.append(
        f"  recommended_value={event.ai_recommended_value}   "
        f"priority={event.ai_recommended_priority}   "
        f"ai_confidence={event.ai_confidence:.2f}"
    )
    lines.append(_rule())

    lines.append("PPM-EDGE DECISION  [deterministic, process()]")
    lines.append(
        f"  threshold={event.threshold}   priority(submitted)={event.priority}"
    )
    lines.append(
        f"  delta={event.delta}   protected={event.protected}   "
        f"confidence={event.confidence}"
    )
    lines.append(f"  new_last_value={event.new_last_value}")
    lines.append("=" * WIDTH)
    return "\n".join(lines)


def render_evidence_summary(
    mode: str,
    event_count: int,
    mismatches: int,
    replay_status: str,
    prior_evidence: dict,
) -> str:
    lines = []
    lines.append("=" * WIDTH)
    lines.append(" EVIDENCE")
    lines.append(_rule())
    lines.append(f"  mode: {mode}")
    lines.append(f"  events processed this run: {event_count}")
    lines.append(f"  mismatches (independent oracle check): {mismatches}")
    lines.append(f"  replay status: {replay_status}")
    lines.append(_rule())
    lines.append("  prior benchmark/correctness evidence (not re-measured by this demo):")
    ck = prior_evidence["c_kernel"]
    ce = prior_evidence["cpython_extension_process"]
    pp = prior_evidence["pure_python"]
    cb = prior_evidence["cpython_extension_process_batch_1024"]
    lines.append(f"    C kernel:           {ck['latency']}; heap alloc after init: {ck['heap_allocation_after_init'].split(' (')[0]}")
    lines.append(f"    C extension process(): {ce['mean_latency']}, {ce['throughput']}")
    lines.append(f"    pure Python:        {pp['mean_latency']}, {pp['throughput']}")
    lines.append(f"    process_batch(1024): {cb['latency']}, {cb['throughput']} -- {cb['note']}")
    lines.append(f"    decision: {prior_evidence['decision']}")
    lines.append("=" * WIDTH)
    return "\n".join(lines)
