"""Deterministic input streams for the three demo modes.

REPLAY and BOUNDARY TEST both need *exact*, checked-in vectors -- their
whole purpose is reproducibility and specific edge-case coverage, so
neither is allowed to depend on the (seeded but still incidental) AI
recommender. LIVE mode is the one place the simulated AI recommendation
actually drives the value/priority submitted to PPM-Edge.
"""
from dataclasses import dataclass
from typing import Iterator, List, Tuple
import random

from ppm_edge.runtime import Priority

REPLAY_INITIAL_VALUE = 500

# Fixed (value, threshold, priority) vectors. Checked in as-is; do not
# regenerate at runtime -- exact reproducibility is the point of REPLAY.
REPLAY_STREAM: List[Tuple[int, int, Priority]] = [
    (520, 100, Priority.NORMAL),
    (610, 50, Priority.NORMAL),
    (615, 50, Priority.HIGH),
    (615, 50, Priority.NORMAL),
    (400, 30, Priority.CRITICAL),
    (405, 30, Priority.LOW),
    (900, 1000, Priority.NORMAL),
    (900, 1000, Priority.NORMAL),
    (-200, 40, Priority.NORMAL),
    (-200, 40, Priority.CRITICAL),
]


def replay_stream() -> List[Tuple[int, int, Priority]]:
    """Return a fresh copy of the fixed replay vector list."""
    return list(REPLAY_STREAM)


@dataclass(frozen=True)
class BoundaryCase:
    label: str
    value: int
    threshold: int
    priority: Priority
    what_it_exercises: str


def boundary_stream(initial_value: int = 0) -> List[BoundaryCase]:
    """Deliberate edge cases, run in order from a runtime initialized to
    `initial_value`. Order matters: some cases build on the state left by
    the previous one (documented per-case below)."""
    return [
        BoundaryCase(
            "zero_threshold",
            initial_value + 1,
            0,
            Priority.NORMAL,
            "threshold=0: any nonzero delta must trigger protection",
        ),
        BoundaryCase(
            "zero_delta",
            initial_value + 1,
            0,
            Priority.NORMAL,
            "same value resubmitted (delta=0) at threshold=0: confidence=100, "
            "but protected is STILL True here because delta(0) >= threshold(0) "
            "-- the >= comparison includes equality, so a zero threshold "
            "protects even a zero delta. See int32_max/int32_min below for "
            "a case where protection follows from a genuinely nonzero delta.",
        ),
        BoundaryCase(
            "negative_threshold",
            initial_value + 2,
            -50,
            Priority.NORMAL,
            "threshold<0 clamps to 0 -- behaves identically to zero_threshold",
        ),
        BoundaryCase(
            "int32_max",
            2147483647,
            1000,
            Priority.NORMAL,
            "signal at INT32_MAX",
        ),
        BoundaryCase(
            "int32_min",
            -2147483648,
            1000,
            Priority.NORMAL,
            "signal at INT32_MIN immediately after INT32_MAX: maximal delta",
        ),
        BoundaryCase(
            "critical_override",
            -2147483647,
            2147483647,
            Priority.CRITICAL,
            "CRITICAL priority forces protection even with threshold=INT32_MAX",
        ),
    ]


def live_stream(seed: int = 0, start: int = 500) -> Iterator[Tuple[int, int]]:
    """Infinite simulated real-time signal generator: yields
    (threshold, ai_seed_unused) is NOT what this returns -- see demo/cli.py,
    which pairs each tick with a call to SimulatedAIRecommender.recommend()
    for the actual value/priority. This generator only supplies the
    externally-configured threshold for each tick (a safety-policy
    parameter, not something the AI proposes).
    """
    rng = random.Random(seed)
    thresholds = [20, 30, 50, 100]
    while True:
        yield rng.choice(thresholds)
