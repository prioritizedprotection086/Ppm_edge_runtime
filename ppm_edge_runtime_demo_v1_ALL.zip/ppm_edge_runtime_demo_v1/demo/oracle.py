"""Independent oracle recomputation, used ONLY to verify/audit this demo's
own event log against PPM-Edge's documented semantics.

This is not a reimplementation used to make any actual decision -- every
real decision in this demo comes from `ppm_edge.runtime.PPMRuntime.process()`
itself, unmodified. This module exists purely so REPLAY and BOUNDARY TEST
can report an independently-checked mismatch count in the EVIDENCE panel,
the same discipline used in the earlier benchmark/correctness work for this
repository.
"""
from typing import Optional

from ppm_edge.runtime import Priority
from .events import DemoEvent


def oracle_step(value: int, threshold: int, priority: Priority, previous_last_value: int):
    th = max(0, int(threshold))
    delta = abs(int(value) - int(previous_last_value))
    protected = delta >= th or priority == Priority.CRITICAL
    if delta == 0:
        confidence = 100
    elif delta < th:
        confidence = 75
    else:
        confidence = 50
    return delta, protected, confidence


def verify_event(event: DemoEvent) -> Optional[str]:
    """Return None if the event matches the oracle, else a description of
    the mismatch."""
    exp_delta, exp_protected, exp_confidence = oracle_step(
        event.input_value,
        event.threshold,
        Priority[event.priority],
        event.previous_last_value,
    )
    problems = []
    if event.delta != exp_delta:
        problems.append(f"delta {event.delta} != expected {exp_delta}")
    if event.protected != exp_protected:
        problems.append(f"protected {event.protected} != expected {exp_protected}")
    if event.confidence != exp_confidence:
        problems.append(f"confidence {event.confidence} != expected {exp_confidence}")
    if event.new_last_value != event.input_value:
        problems.append("new_last_value != input_value")
    return "; ".join(problems) if problems else None
