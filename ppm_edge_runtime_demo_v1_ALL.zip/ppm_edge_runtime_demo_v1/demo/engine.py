"""Thin integration layer: AI proposes -> PPM-Edge evaluates -> auditable event.

Wraps `ppm_edge.runtime.PPMRuntime` exactly as characterized -- this module
never touches PPMRuntime's internals, never subclasses it, and never
reimplements any part of its decision logic. It only calls
`PPMRuntime.process()` once per step and records the result.
"""
from typing import List, Optional

from ppm_edge.runtime import PPMRuntime, InputSample, Priority

from .recommender import SimulatedAIRecommender, AIRecommendation
from .events import DemoEvent


class DemoEngine:
    def __init__(self, initial_value: int = 0, ai_seed: int = 0) -> None:
        self.runtime = PPMRuntime(initial_value=initial_value)
        self.recommender = SimulatedAIRecommender(seed=ai_seed)
        self.events: List[DemoEvent] = []
        self._sequence = 0

    def step(
        self,
        mode: str,
        value: int,
        threshold: int,
        priority: Priority,
        case_label: str = "",
        ai_reco: Optional[AIRecommendation] = None,
    ) -> DemoEvent:
        """Run one (value, threshold, priority) through the unmodified
        PPM-Edge runtime and record a structured, auditable event.

        `ai_reco`, if not supplied, is generated here for display purposes
        only -- it never influences `value`/`threshold`/`priority` in this
        method. Callers that want the AI recommendation to actually drive
        the submitted value/priority (LIVE mode) compute it themselves and
        pass it in, using its fields as `value`/`priority` before calling
        `step()`. This keeps the "what did the AI propose" vs. "what did
        we actually submit to PPM-Edge" distinction explicit and auditable
        even when they happen to be equal.
        """
        previous_last_value = self.runtime.state.last_value
        if ai_reco is None:
            ai_reco = self.recommender.recommend(previous_last_value)

        decision = self.runtime.process(
            InputSample(value=value, threshold=threshold, priority=priority)
        )

        self._sequence += 1
        event = DemoEvent(
            sequence=self._sequence,
            mode=mode,
            case_label=case_label,
            ai_recommended_value=ai_reco.recommended_value,
            ai_recommended_priority=ai_reco.recommended_priority.name,
            ai_confidence=ai_reco.ai_confidence,
            input_value=value,
            threshold=threshold,
            priority=priority.name,
            previous_last_value=previous_last_value,
            delta=decision.delta,
            protected=decision.protected,
            confidence=decision.confidence,
            new_last_value=self.runtime.state.last_value,
        )
        self.events.append(event)
        return event

    def final_state_tuple(self):
        s = self.runtime.state
        return (s.baseline, s.last_value, s.initialized, s.protected, s.confidence, int(s.priority))
