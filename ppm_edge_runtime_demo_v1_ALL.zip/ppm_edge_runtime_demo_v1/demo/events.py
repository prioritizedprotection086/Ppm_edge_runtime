"""Structured, auditable event record for the PPM-Edge demo.

Every processed event carries, at minimum, the fields called out in the
V1 spec: sequence, input_value, threshold, priority, previous_last_value,
delta, protected, confidence, new_last_value. The AI-side fields are
additional context, kept clearly separate (an `ai_` prefix) so it's always
obvious which fields came from the simulated recommender and which came
from the deterministic PPM-Edge decision.
"""
from dataclasses import dataclass, asdict, fields


@dataclass(frozen=True)
class DemoEvent:
    sequence: int
    mode: str
    case_label: str  # e.g. "zero_threshold", "" for live/replay steps

    # Simulated AI recommendation (context only -- see demo/recommender.py)
    ai_recommended_value: int
    ai_recommended_priority: str
    ai_confidence: float

    # Exact inputs submitted to PPMRuntime.process()
    input_value: int
    threshold: int
    priority: str

    # PPM-Edge deterministic output / state transition (the audit trail)
    previous_last_value: int
    delta: int
    protected: bool
    confidence: int
    new_last_value: int

    def to_dict(self) -> dict:
        return asdict(self)


REQUIRED_MINIMUM_FIELDS = {
    "sequence",
    "input_value",
    "threshold",
    "priority",
    "previous_last_value",
    "delta",
    "protected",
    "confidence",
    "new_last_value",
}


def _check_minimum_fields() -> None:
    present = {f.name for f in fields(DemoEvent)}
    missing = REQUIRED_MINIMUM_FIELDS - present
    if missing:  # pragma: no cover - defensive, should never trigger
        raise AssertionError(f"DemoEvent is missing required fields: {missing}")


_check_minimum_fields()
