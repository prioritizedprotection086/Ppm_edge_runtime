"""Simulated AI recommendation layer.

*** THIS IS NOT A REAL AI MODEL. ***

`SimulatedAIRecommender` is a small, seeded, deterministic stand-in for an
upstream probabilistic/ML recommendation source. Its only job is to give
the demo something to show in the AI RECOMMENDATION panel so the boundary
between "probabilistic proposal" and "deterministic decision" is visible
end-to-end. It carries no claim of predictive quality and should never be
treated as, extended into, or confused with an actual trained model.

Nothing here is imported by or referenced from Src/Ppm_edge.c,
Src/Ppm_edge.h, or src/ppm_edge/runtime.py, and nothing here feeds back
into those files. The PPM-Edge decision is made entirely by
`ppm_edge.runtime.PPMRuntime.process()`, unmodified.
"""
from dataclasses import dataclass
import random

from ppm_edge.runtime import Priority


@dataclass(frozen=True)
class AIRecommendation:
    """A single simulated recommendation.

    `ai_confidence` is the *simulated model's own* confidence estimate
    (0.0-1.0). It is intentionally a different quantity from PPM-Edge's
    `confidence` field (0/50/75/100) computed later by the deterministic
    kernel -- the demo keeps these visually and semantically separate on
    purpose.
    """

    recommended_value: int
    recommended_priority: Priority
    ai_confidence: float


class SimulatedAIRecommender:
    """Deterministic, seeded stand-in for an upstream recommendation source."""

    def __init__(self, seed: int = 0) -> None:
        self._rng = random.Random(seed)

    def recommend(self, current_signal: int) -> AIRecommendation:
        drift = self._rng.randint(-50, 50)
        recommended_value = current_signal + drift
        ai_confidence = round(self._rng.uniform(0.55, 0.99), 2)

        # Deliberately crude, clearly-fake heuristic -- large proposed jumps
        # skew toward higher suggested priority, and a small fixed fraction
        # of recommendations are flagged CRITICAL so the demo regularly
        # exercises PPM-Edge's priority-override protection path.
        magnitude = abs(drift)
        roll = self._rng.random()
        if roll < 0.05:
            priority = Priority.CRITICAL
        elif magnitude > 35:
            priority = Priority.HIGH
        elif magnitude > 15:
            priority = Priority.NORMAL
        else:
            priority = Priority.LOW

        return AIRecommendation(
            recommended_value=recommended_value,
            recommended_priority=priority,
            ai_confidence=ai_confidence,
        )
