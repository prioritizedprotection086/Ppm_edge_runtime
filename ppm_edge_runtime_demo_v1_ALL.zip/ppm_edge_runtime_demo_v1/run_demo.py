#!/usr/bin/env python3
"""One-command launcher for the PPM-Edge AI-to-Action demonstrator.

Usage:
    python3 run_demo.py --mode live
    python3 run_demo.py --mode replay
    python3 run_demo.py --mode boundary

Run `python3 run_demo.py --help` for all options.
"""
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO_ROOT / "src"))
sys.path.insert(0, str(REPO_ROOT))

from demo.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
