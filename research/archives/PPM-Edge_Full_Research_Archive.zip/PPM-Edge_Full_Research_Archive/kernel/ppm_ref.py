#!/usr/bin/env python3
"""Pure-Python reference implementation of PPM-Edge kernel (RECONSTRUCTED).
Matches the C semantics in Ppm_edge.c exactly for in-contract behavior.
Does not modify production sources.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum
from typing import Optional


class Priority(IntEnum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class InputSample:
    signal: int
    threshold: int
    priority: Priority = Priority.NORMAL
    baseline: int = 0
    confidence: int = 100


@dataclass
class OutputSample:
    value: int
    delta: int
    protected_mode: bool
    confidence: int
    priority: Priority


@dataclass
class RuntimeState:
    baseline: int = 0
    last_value: int = 0
    threshold: int = 0
    initialized: bool = False
    protection: bool = False
    confidence: int = 0
    priority: Priority = Priority.NORMAL


def _absolute_delta(a: int, b: int) -> int:
    difference = a - b
    if difference < 0:
        difference = -difference
    if difference > 0xFFFFFFFF:
        return 0xFFFFFFFF
    return difference


def _calculate_confidence(delta: int, threshold: int) -> int:
    if delta == 0:
        return 100
    if delta < threshold:
        return 75
    return 50


class PPMRuntime:
    """Deterministic pure-Python reference matching C ppm_process."""

    def __init__(self, baseline: int = 0, threshold: int = 0):
        self.state = RuntimeState(
            baseline=baseline,
            last_value=baseline,
            threshold=max(0, threshold),
        )

    def reset(self) -> None:
        self.state.last_value = self.state.baseline
        self.state.initialized = False
        self.state.protection = False
        self.state.confidence = 0
        self.state.priority = Priority.NORMAL

    def process(self, inp: InputSample) -> OutputSample:
        threshold_value = max(0, int(inp.threshold))
        delta = _absolute_delta(int(inp.signal), self.state.last_value)
        protected = (delta >= threshold_value) or (inp.priority == Priority.CRITICAL)
        conf = _calculate_confidence(delta, threshold_value)

        self.state.last_value = int(inp.signal)
        self.state.threshold = threshold_value
        self.state.initialized = True
        self.state.protection = protected
        self.state.confidence = conf
        self.state.priority = inp.priority

        return OutputSample(
            value=int(inp.signal),
            delta=delta,
            protected_mode=protected,
            confidence=conf,
            priority=inp.priority,
        )


def oracle(value: int, threshold: int, priority: int, last: int) -> dict:
    """Contract oracle used for differential checks."""
    th = max(0, int(threshold))
    delta = _absolute_delta(int(value), last)
    prot = (delta >= th) or (priority == 3)
    conf = 100 if delta == 0 else (75 if delta < th else 50)
    return {
        "value": value,
        "delta": delta,
        "protected": prot,
        "confidence": conf,
        "priority": priority,
    }
