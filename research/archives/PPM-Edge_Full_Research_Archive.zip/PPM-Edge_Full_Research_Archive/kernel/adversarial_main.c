/* Standalone adversarial harness — does not modify production sources.
 * Compiles against the existing Ppm_edge.c / .h as-is.
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "Ppm_edge.h"

static void check(int cond, const char *msg) {
    if (!cond) {
        fprintf(stderr, "CONTRACT VIOLATION: %s\n", msg);
        exit(1);
    }
}

static uint32_t abs_delta_ref(int32_t a, int32_t b) {
    int64_t d = (int64_t)a - (int64_t)b;
    if (d < 0) d = -d;
    if (d > UINT32_MAX) return UINT32_MAX;
    return (uint32_t)d;
}

static void assert_contract(const ppm_runtime_t *rt,
                            const ppm_input_t *in,
                            const ppm_output_t *out,
                            int32_t prev_last) {
    uint32_t expect_delta = abs_delta_ref(in->signal, prev_last);
    int32_t th = in->threshold < 0 ? 0 : in->threshold;
    int expect_prot = (expect_delta >= (uint32_t)th) || (in->priority == PPM_PRIORITY_CRITICAL);
    uint8_t expect_conf;
    if (expect_delta == 0) expect_conf = 100;
    else if (expect_delta < (uint32_t)th) expect_conf = 75;
    else expect_conf = 50;

    check(out->value == in->signal, "output value != input signal");
    check(out->delta == expect_delta, "delta mismatch");
    check(out->protected_mode == (uint8_t)expect_prot, "protected mismatch");
    check(out->confidence == expect_conf, "confidence mismatch");
    check(out->priority == in->priority, "priority echo mismatch");
    check(rt->last_value == in->signal, "last_value not updated");
}

int main(void) {
    ppm_runtime_t rt;
    ppm_init(&rt, 0, 0);

    printf("C adversarial harness starting\n");

    /* 1. Gradual drift + alternating priorities */
    {
        int32_t prev = 0;
        for (int i = 0; i < 10000; i++) {
            ppm_input_t in;
            in.signal = (int32_t)(i * 3);
            in.threshold = 10 + (i % 50);
            in.priority = (i % 2 == 0) ? PPM_PRIORITY_LOW : PPM_PRIORITY_HIGH;
            if (i % 200 == 0) in.priority = PPM_PRIORITY_CRITICAL;
            ppm_output_t out;
            int32_t before = rt.last_value;
            ppm_process(&rt, &in, &out);
            assert_contract(&rt, &in, &out, before);
            prev = in.signal;
        }
        printf("  gradual drift + alternating priorities: PASS (10000 steps)\n");
    }

    /* 2. Repeated boundary crossings around a fixed threshold */
    {
        ppm_reset(&rt);
        int32_t center = 1000;
        for (int i = 0; i < 5000; i++) {
            ppm_input_t in;
            in.signal = center + ((i % 2 == 0) ? 25 : -25);
            in.threshold = 20;
            in.priority = PPM_PRIORITY_NORMAL;
            int32_t before = rt.last_value;
            ppm_output_t out;
            ppm_process(&rt, &in, &out);
            assert_contract(&rt, &in, &out, before);
        }
        printf("  repeated boundary crossings: PASS (5000 steps)\n");
    }

    /* 3. Extreme event then recovery */
    {
        ppm_reset(&rt);
        ppm_input_t extreme = { .signal = INT32_MIN, .threshold = 0, .priority = PPM_PRIORITY_CRITICAL };
        ppm_output_t out;
        int32_t before = rt.last_value;
        ppm_process(&rt, &extreme, &out);
        assert_contract(&rt, &extreme, &out, before);

        for (int i = 0; i < 1000; i++) {
            ppm_input_t in = { .signal = i, .threshold = 5, .priority = PPM_PRIORITY_NORMAL };
            before = rt.last_value;
            ppm_process(&rt, &in, &out);
            assert_contract(&rt, &in, &out, before);
        }
        printf("  recovery after extreme (INT32_MIN + CRITICAL): PASS\n");
    }

    /* 4. Conflicting recommendations (individually valid) */
    {
        ppm_reset(&rt);
        for (int i = 0; i < 2000; i++) {
            ppm_input_t in;
            in.signal = (i % 3 == 0) ? 500 : (i % 3 == 1) ? -500 : 0;
            in.threshold = (i % 5 == 0) ? 0 : 100;
            in.priority = (i % 7 == 0) ? PPM_PRIORITY_CRITICAL : PPM_PRIORITY_NORMAL;
            int32_t before = rt.last_value;
            ppm_output_t out;
            ppm_process(&rt, &in, &out);
            assert_contract(&rt, &in, &out, before);
        }
        printf("  conflicting valid recommendations: PASS\n");
    }

    /* 5. Replay earlier sequence after state change */
    {
        ppm_reset(&rt);
        ppm_input_t seq[5] = {
            {100, 20, PPM_PRIORITY_NORMAL},
            {130, 20, PPM_PRIORITY_NORMAL},
            {125, 20, PPM_PRIORITY_NORMAL},
            {200, 20, PPM_PRIORITY_HIGH},
            {201, 20, PPM_PRIORITY_NORMAL},
        };
        ppm_output_t first_run[5];
        for (int i = 0; i < 5; i++) {
            int32_t before = rt.last_value;
            ppm_process(&rt, &seq[i], &first_run[i]);
            assert_contract(&rt, &seq[i], &first_run[i], before);
        }
        /* move state far away */
        ppm_input_t jump = { INT32_MAX, 0, PPM_PRIORITY_CRITICAL };
        ppm_output_t junk;
        ppm_process(&rt, &jump, &junk);

        /* replay same sequence — decisions must still obey contract relative to *new* last_value */
        for (int i = 0; i < 5; i++) {
            int32_t before = rt.last_value;
            ppm_output_t out;
            ppm_process(&rt, &seq[i], &out);
            assert_contract(&rt, &seq[i], &out, before);
            /* Not required to equal first_run — state has changed — only contract */
        }
        printf("  replay after state change: PASS (contract held; outputs correctly differ)\n");
    }

    /* 6. Very long sequence */
    {
        ppm_reset(&rt);
        for (int i = 0; i < 200000; i++) {
            ppm_input_t in;
            in.signal = (int32_t)((i * 1103515245u + 12345u) ^ (i << 3));
            in.threshold = (i % 100);
            in.priority = (i % 53 == 0) ? PPM_PRIORITY_CRITICAL : (ppm_priority_t)(i % 4);
            int32_t before = rt.last_value;
            ppm_output_t out;
            ppm_process(&rt, &in, &out);
            assert_contract(&rt, &in, &out, before);
        }
        printf("  very long sequence (200k): PASS — no contract violation\n");
    }

    printf("\nALL C ADVERSARIAL CHECKS PASSED\n");
    return 0;
}
