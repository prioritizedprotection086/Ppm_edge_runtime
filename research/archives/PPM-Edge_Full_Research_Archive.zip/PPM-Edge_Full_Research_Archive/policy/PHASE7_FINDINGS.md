# Phase 7 Findings — Threshold Surface, Attack Sequences, Policy, Red-Team

**Generated:** 2026-08-17T03:41:11Z
**Label:** RECONSTRUCTED / NEW experiments in Grok sandbox
**Constraint:** Production kernel untouched

## 1. How much harmful trajectory is permitted while every event stays compliant?

Every grid cell with step = threshold−k (k≥1) yields **0% PROTECT**.
Long streams (100k events, th=20, Δ=19) produce path length 1.9M and net ±1.9M with zero protections.
Initial state does not matter; the contract is memoryless except for last_value.

## 2–3. Minimum additional policy and which holes it closes

| Control | Closes slow_drift | Closes chatter/camp | FP on small walk |
|---------|-------------------|---------------------|------------------|
| authority_delta=20 | Yes (steps >20 blocked) | Partial | Low |
| cum_disp_limit=500 | Yes (unbounded drift) | No | Low if limit >> normal |
| rate limit | Partial | Partial | Low if tuned |
| chatter limit | No | Partial | **High** |
| **auth + cum (minimal set)** | **Yes** | **Partial** | **Low on small walks** |

Chatter that stays inside the authority band still passes; residual in-band attacks remain.

## 4. Tradeoffs introduced

- Origin dependence: long honest ramps eventually hit cum_disp unless origin is updated.
- Authority floor: too tight rejects legitimate fast moves.
- No semantic understanding of intent or contradiction.
- Latency/memory: O(window) history for rate/chatter; negligible for auth+cum alone.

## 5. Attack classes still outside scope

Anything that respects both numeric envelopes (authority + cumulative displacement from a fixed origin).
Goal appropriateness, contradiction between successive high-confidence recommendations, world-model violations.

## 6. Controllability when adversary understands the boundary

An adversary that knows (threshold, authority, cum_limit) can still produce non-trivial path length
and chatter inside the box. The architecture remains a numeric interlock, not a semantic guard.
It stops blunt/incompetent large moves; it does not stop a capable optimizer that respects the envelopes.

## Evidence

- results/phase7a_threshold_surface.json
- results/phase7b_attack_sequences.json (event traces head/tail + seq fingerprints)
- results/phase7c_policy_ablation.json
- results/phase7d_redteam.json

C adversarial harness previously confirmed no contract violations under long adversarial input.
