"""Minimal external policy layer (RECONSTRUCTED).
Does not modify PPM-Edge. Candidate controls for demonstrated bypasses only.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Any

@dataclass
class PolicyConfig:
    cum_disp_limit: Optional[int] = None
    rate_limit: Optional[int] = None
    rate_window: int = 10
    authority_delta: Optional[int] = None
    chatter_limit: Optional[int] = None
    chatter_window: int = 20

@dataclass
class PolicyState:
    origin: int = 0
    history: List[int] = field(default_factory=list)
    signed_steps: List[int] = field(default_factory=list)
    blocked: int = 0
    passed: int = 0

class MinPolicy:
    def __init__(self, authority_delta: int, cum_disp_limit: int, origin: int = 0):
        self.auth = authority_delta
        self.cum = cum_disp_limit
        self.origin = origin
        self.blocked = 0
        self.passed = 0

    def filter(self, sample: Any, last: int) -> Tuple[Optional[Any], str]:
        d = abs(sample.value - last)
        if d > self.auth:
            self.blocked += 1
            return None, "authority"
        if abs(sample.value - self.origin) > self.cum:
            self.blocked += 1
            return None, "cum_disp"
        self.passed += 1
        return sample, "pass"
