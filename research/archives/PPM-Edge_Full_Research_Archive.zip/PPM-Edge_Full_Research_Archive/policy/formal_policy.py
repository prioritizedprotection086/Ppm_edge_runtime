#!/usr/bin/env python3
"""Formal experimental policy layer (RECONSTRUCTED).

Phase 8 baseline: authority_delta + cumulative displacement relative to origin.
Production PPM-Edge kernel is never modified.

This module defines the *exact* state variables and transition rules so that
attacks can be evaluated against a precise allowed-trajectory definition.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Tuple, Dict, Any
import hashlib
import json


@dataclass
class PolicyConfig:
    """Static configuration of the experimental policy."""
    authority_delta: int          # max |signal - last| per accepted event
    cum_disp_limit: int           # max |signal - origin| at any accepted event
    # Origin-update rules (experimental; higher-authority only in real system)
    origin_update_requires_auth: bool = True   # only "authorized" actor may move origin
    origin_update_cost: int = 0                # optional: must spend path budget / events
    # Reset / recovery
    allow_origin_reset_to_current: bool = True # set origin := current value
    allow_full_reset: bool = False             # wipe history + origin to baseline (off by default)


@dataclass
class PolicyState:
    origin: int = 0
    last_accepted: int = 0
    events_accepted: int = 0
    events_rejected: int = 0
    origin_updates: int = 0
    total_path: int = 0          # Σ|Δ| over accepted events only
    max_excursion: int = 0       # max |value - initial_origin| observed
    block_reasons: Dict[str, int] = field(default_factory=dict)
    history_deltas: List[int] = field(default_factory=list)  # optional audit
    transition_log: List[str] = field(default_factory=list)  # state-machine trace


class FormalPolicy:
    """
    State machine for the experimental policy.

    Allowed trajectory (definition):
      A sequence of values v_0, v_1, ... is allowed under config C and initial
      origin o_0 iff for every accepted step i:
        1. |v_i - v_{i-1}| <= C.authority_delta          (authority envelope)
        2. |v_i - origin_i|  <= C.cum_disp_limit         (cumulative envelope)
      where origin may only change via explicit origin-update transitions
      that themselves obey the rules in C.

    Rejected events do not update last_accepted or path.
    """

    def __init__(self, config: PolicyConfig, origin: int = 0, last: int = 0):
        self.cfg = config
        self.state = PolicyState(origin=origin, last_accepted=last)
        self.initial_origin = origin
        self._authorized = True  # experimental: assume we hold the update token

    # ---- queries ----
    def is_allowed(self, value: int, last: Optional[int] = None) -> Tuple[bool, str]:
        last = self.state.last_accepted if last is None else last
        d = abs(value - last)
        if d > self.cfg.authority_delta:
            return False, "authority"
        if abs(value - self.state.origin) > self.cfg.cum_disp_limit:
            return False, "cum_disp"
        return True, "pass"

    # ---- transitions ----
    def try_accept(self, value: int) -> Tuple[bool, str]:
        """Attempt to accept a movement. Updates state only on success."""
        ok, reason = self.is_allowed(value)
        if not ok:
            self.state.events_rejected += 1
            self.state.block_reasons[reason] = self.state.block_reasons.get(reason, 0) + 1
            self.state.transition_log.append(f"REJECT:{reason}")
            return False, reason
        d = abs(value - self.state.last_accepted)
        self.state.total_path += d
        self.state.last_accepted = value
        self.state.events_accepted += 1
        self.state.max_excursion = max(
            self.state.max_excursion,
            abs(value - self.initial_origin),
        )
        self.state.history_deltas.append(d)
        self.state.transition_log.append("ACCEPT")
        return True, "pass"

    def update_origin(self, new_origin: Optional[int] = None, force: bool = False) -> Tuple[bool, str]:
        """
        Advance origin. Default: set origin to current last_accepted
        (replenishes the cumulative budget around the new operating point).

        In a real system this would require a higher-authority token.
        Here we model that token as self._authorized.
        """
        if self.cfg.origin_update_requires_auth and not (self._authorized or force):
            self.state.transition_log.append("ORIGIN_DENIED")
            return False, "origin_denied"
        if new_origin is None:
            if not self.cfg.allow_origin_reset_to_current:
                return False, "origin_reset_disabled"
            new_origin = self.state.last_accepted
        self.state.origin = new_origin
        self.state.origin_updates += 1
        self.state.transition_log.append(f"ORIGIN->{new_origin}")
        return True, "origin_updated"

    def set_authorized(self, flag: bool) -> None:
        self._authorized = flag
        self.state.transition_log.append(f"AUTH_TOKEN={flag}")

    def full_reset(self, baseline: int = 0) -> Tuple[bool, str]:
        if not self.cfg.allow_full_reset:
            return False, "full_reset_disabled"
        self.state = PolicyState(origin=baseline, last_accepted=baseline)
        self.initial_origin = baseline
        self.state.transition_log.append("FULL_RESET")
        return True, "reset"

    def snapshot(self) -> Dict[str, Any]:
        return {
            "config": asdict(self.cfg),
            "state": {
                "origin": self.state.origin,
                "last_accepted": self.state.last_accepted,
                "events_accepted": self.state.events_accepted,
                "events_rejected": self.state.events_rejected,
                "origin_updates": self.state.origin_updates,
                "total_path": self.state.total_path,
                "max_excursion": self.state.max_excursion,
                "block_reasons": dict(self.state.block_reasons),
            },
            "initial_origin": self.initial_origin,
            "authorized": self._authorized,
        }

    def fingerprint(self) -> str:
        raw = json.dumps(self.snapshot(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode()).hexdigest()[:16]
