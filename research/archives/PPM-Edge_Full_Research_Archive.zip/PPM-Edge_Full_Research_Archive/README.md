# PPM-Edge Research Archive
**Numeric Safety Envelopes, Authority, and Origin-Update**

This archive contains the complete research chain from the real PPM-Edge C kernel through experimental policy layers and red-team results.

## Structure

```
kernel/          – Actual C runtime (Ppm_edge.c / .h) and reference
policy/          – FormalPolicy experimental layer (authority_delta, cum_disp, origin)
harness/         – Test harnesses (Phase 12 global-budget harness + Phase 13 FormalPolicy attacks)
phases/          – Phase 9–13 reports, designs, and intermediate zips
results/         – Machine-readable JSON results
```

## Key Finding

A spatial envelope (`|value - origin| ≤ cum_disp_limit`) plus a per-step authority limit does **not** bound lifetime activity (`Σ|Δ|`) when origin-update is unconstrained.

- When origin-update is available → path scales with number of updates (unbounded).
- When origin-update is denied → path is bounded by the fixed-origin envelope.
- Minimal fix: non-replenishable global path budget + single-use, higher-privilege origin tokens + independent origin-update budget.

## Important Distinction

- **C kernel** (`kernel/Ppm_edge.c`): simple per-step threshold + priority. No path budget, no origin mechanism.
- **FormalPolicy** (`policy/formal_policy.py`): experimental layer that implements authority_delta, cum_disp_limit, origin, total_path. This is where the unbounded-path constructions were demonstrated.

## Reproducing Phase 13 results

```bash
python3 harness/phase13_formal_policy_redteam.py
```

## Phases Summary

| Phase | Content |
|-------|---------|
| 9 | Authority/capability red team – origin-update as capability |
| 10 | Boundary stress & budget evasion |
| 11 | Implementation audit checklist |
| 12 | Experimental harness design + global path budget proof |
| 13 | FormalPolicy red-team (reconfirmed unbounded path under origin replenish) |

## License / Use

Research artifact. Production PPM-Edge kernel was never modified. Use for analysis, hardening design, and further testing.
