#!/usr/bin/env python3
"""
Phase 13 – Continue testing FormalPolicy (the layer that actually has
authority_delta, cum_disp_limit, origin, total_path).

Replays Phase 8 unbounded constructions and extends them.
Production C kernel is never touched.
"""
from __future__ import annotations
import json
import sys
sys.path.insert(0, "/home/workdir/artifacts/ppm_phase8")
import formal_policy as fp
from dataclasses import asdict

def run_attack(name: str, cfg: fp.PolicyConfig, steps: list, authorized: bool = True):
    """steps is a list of ('move', delta) or ('origin', new_origin) or ('reset_origin',)"""
    pol = fp.FormalPolicy(cfg, origin=0, last=0)
    pol.set_authorized(authorized)
    results = []
    for kind, *args in steps:
        if kind == "move":
            delta = args[0]
            target = pol.state.last_accepted + delta
            ok = pol.try_accept(target)
            results.append(("move", delta, ok, pol.state.total_path, pol.state.origin))
        elif kind == "origin":
            new_o = args[0]
            ok = pol.update_origin(new_o)
            results.append(("origin", new_o, ok, pol.state.total_path, pol.state.origin))
        elif kind == "reset_origin":
            ok = pol.update_origin(pol.state.last_accepted)  # set origin to current
            results.append(("reset_origin", pol.state.last_accepted, ok, pol.state.total_path, pol.state.origin))
    return {
        "name": name,
        "final_path": pol.state.total_path,
        "origin_updates": pol.state.origin_updates,
        "events_accepted": pol.state.events_accepted,
        "events_rejected": pol.state.events_rejected,
        "max_excursion": pol.state.max_excursion,
        "block_reasons": dict(pol.state.block_reasons),
        "final_origin": pol.state.origin,
        "final_value": pol.state.last_accepted,
        "fingerprint": pol.fingerprint(),
    }

def main():
    AUTH = 20
    CUM  = 500

    cfg = fp.PolicyConfig(
        authority_delta=AUTH,
        cum_disp_limit=CUM,
        origin_update_requires_auth=True,
        origin_update_cost=0,
        allow_origin_reset_to_current=True,
        allow_full_reset=False,
    )

    report = {"config": asdict(cfg), "attacks": []}

    # ---- Attack 1: Fixed-origin oscillation (should be bounded by 2*CUM) ----
    steps = []
    # bounce ±AUTH-1 inside the envelope
    for i in range(5000):
        steps.append(("move", (AUTH-1) if (i % 2 == 0) else -(AUTH-1)))
    r = run_attack("fixed_origin_oscillation_5k", cfg, steps, authorized=False)
    report["attacks"].append(r)
    print(f"[1] fixed_origin_oscillation  path={r['final_path']} accepted={r['events_accepted']} rejected={r['events_rejected']}")

    # ---- Attack 2: Min-cost origin replenish (Phase 8 classic) ----
    # Each cycle: move +AUTH-1, then rebase origin to current → path grows without spatial violation
    steps = []
    for i in range(2000):
        steps.append(("move", AUTH-1))
        steps.append(("reset_origin",))
    r = run_attack("min_cost_origin_2000", cfg, steps, authorized=True)
    report["attacks"].append(r)
    print(f"[2] min_cost_origin_2000     path={r['final_path']} origin_updates={r['origin_updates']}")

    # ---- Attack 3: Full-budget replenish (fill the cum envelope then rebase) ----
    steps = []
    for i in range(200):
        # walk to the edge of the envelope
        remaining = CUM
        while remaining >= AUTH-1:
            steps.append(("move", AUTH-1))
            remaining -= (AUTH-1)
        steps.append(("reset_origin",))
    r = run_attack("full_budget_replenish_200", cfg, steps, authorized=True)
    report["attacks"].append(r)
    print(f"[3] full_budget_replenish_200 path={r['final_path']} origin_updates={r['origin_updates']}")

    # ---- Attack 4: Origin updates DENIED – should stay bounded ----
    steps = []
    for i in range(2000):
        steps.append(("move", AUTH-1))
        steps.append(("reset_origin",))
    r = run_attack("origin_denied_2000", cfg, steps, authorized=False)
    report["attacks"].append(r)
    print(f"[4] origin_denied_2000       path={r['final_path']} origin_updates={r['origin_updates']} rejected={r['events_rejected']}")

    # ---- Attack 5: Long-duration low-amplitude chatter (fixed origin) ----
    steps = []
    for i in range(10000):
        steps.append(("move", 1 if (i % 2 == 0) else -1))
    r = run_attack("tiny_chatter_10k", cfg, steps, authorized=False)
    report["attacks"].append(r)
    print(f"[5] tiny_chatter_10k         path={r['final_path']} accepted={r['events_accepted']}")

    # ---- Attack 6: Try to exceed authority_delta ----
    steps = [("move", AUTH), ("move", AUTH+1), ("move", AUTH-1)]
    r = run_attack("authority_violation", cfg, steps, authorized=False)
    report["attacks"].append(r)
    print(f"[6] authority_violation      accepted={r['events_accepted']} rejected={r['events_rejected']} reasons={r['block_reasons']}")

    # ---- Attack 7: Spatial violation without origin update ----
    steps = []
    for _ in range(40):
        steps.append(("move", AUTH-1))
    r = run_attack("spatial_violation", cfg, steps, authorized=False)
    report["attacks"].append(r)
    print(f"[7] spatial_violation        path={r['final_path']} rejected={r['events_rejected']} reasons={r['block_reasons']}")

    # Summary
    print("\n=== SUMMARY ===")
    for a in report["attacks"]:
        print(f"  {a['name']}: path={a['final_path']}, origins={a['origin_updates']}, accepted={a['events_accepted']}, rejected={a['events_rejected']}")

    with open("/home/workdir/artifacts/PHASE_13_FORMAL_POLICY_RESULTS.json", "w") as f:
        json.dump(report, f, indent=2)
    print("\nResults written to PHASE_13_FORMAL_POLICY_RESULTS.json")
    return report

if __name__ == "__main__":
    main()
