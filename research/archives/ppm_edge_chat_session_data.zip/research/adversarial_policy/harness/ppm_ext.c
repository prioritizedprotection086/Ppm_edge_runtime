/* Minimal CPython extension wrapping the existing Ppm_edge.c kernel.
 * Does not modify production sources. Sandbox experiment only.
 */
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "Ppm_edge.h"

typedef struct {
    PyObject_HEAD
    ppm_runtime_t rt;
} PpmObject;

static int Ppm_init(PpmObject *self, PyObject *args, PyObject *kw) {
    int baseline = 0, threshold = 0;
    static char *kwlist[] = {"initial_value", "threshold", NULL};
    if (!PyArg_ParseTupleAndKeywords(args, kw, "|ii", kwlist, &baseline, &threshold))
        return -1;
    ppm_init(&self->rt, (int32_t)baseline, (int32_t)threshold);
    return 0;
}

static PyObject *Ppm_process(PpmObject *self, PyObject *args, PyObject *kw) {
    long value, threshold = 0;
    int priority = 1;
    static char *kwlist[] = {"value", "threshold", "priority", NULL};
    if (!PyArg_ParseTupleAndKeywords(args, kw, "l|li", kwlist, &value, &threshold, &priority))
        return NULL;
    ppm_input_t in;
    in.signal = (int32_t)value;
    in.baseline = 0;
    in.threshold = (int32_t)threshold;
    in.confidence = 0;
    in.priority = (ppm_priority_t)priority;
    ppm_output_t out;
    ppm_process(&self->rt, &in, &out);
    return Py_BuildValue("{s:i,s:I,s:i,s:i,s:i}",
        "value", out.value,
        "delta", out.delta,
        "protected", (int)out.protected_mode,
        "confidence", (int)out.confidence,
        "priority", (int)out.priority);
}

static PyObject *Ppm_reset(PpmObject *self, PyObject *Py_UNUSED(ignored)) {
    ppm_reset(&self->rt);
    Py_RETURN_NONE;
}

static PyObject *Ppm_last_value(PpmObject *self, void *closure) {
    return PyLong_FromLong(self->rt.last_value);
}

static PyGetSetDef Ppm_getset[] = {
    {"last_value", (getter)Ppm_last_value, NULL, NULL, NULL},
    {NULL}
};

static PyMethodDef Ppm_methods[] = {
    {"process", (PyCFunction)Ppm_process, METH_VARARGS | METH_KEYWORDS, NULL},
    {"reset", (PyCFunction)Ppm_reset, METH_NOARGS, NULL},
    {NULL}
};

static PyTypeObject PpmType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    .tp_name = "ppm_ext.Ppm",
    .tp_basicsize = sizeof(PpmObject),
    .tp_flags = Py_TPFLAGS_DEFAULT,
    .tp_new = PyType_GenericNew,
    .tp_init = (initproc)Ppm_init,
    .tp_methods = Ppm_methods,
    .tp_getset = Ppm_getset,
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT, "ppm_ext", NULL, -1, NULL
};

PyMODINIT_FUNC PyInit_ppm_ext(void) {
    PyObject *m = PyModule_Create(&module);
    if (!m) return NULL;
    if (PyType_Ready(&PpmType) < 0) return NULL;
    Py_INCREF(&PpmType);
    PyModule_AddObject(m, "Ppm", (PyObject *)&PpmType);
    return m;
}
