from setuptools import setup, Extension
setup(
    name="ppm_ext",
    ext_modules=[Extension("ppm_ext", sources=["ppm_ext.c", "Ppm_edge.c"], include_dirs=["."])],
)
