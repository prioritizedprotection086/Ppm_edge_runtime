#!/usr/bin/env python3
"""Orchestration harness: Python reference vs C extension vs contract oracle (RECONSTRUCTED)."""
from __future__ import annotations
import sys
from pathlib import Path

# Expect to be run with PYTHONPATH including demo src and built ppm_ext
try:
    from ppm_edge.runtime import InputSample, PPMRuntime, Priority
except ImportError:
    print("Need ppm_edge on PYTHONPATH")
    sys.exit(1)

def oracle(value, threshold, priority, last):
    th = max(0, int(threshold))
    delta = abs(int(value) - last)
    if delta > 0xFFFFFFFF:
        delta = 0xFFFFFFFF
    prot = (delta >= th) or (priority == 3)
    conf = 100 if delta == 0 else (75 if delta < th else 50)
    return {"value": value, "delta": delta, "protected": prot, "confidence": conf, "priority": priority}

def compare_one(value, threshold, priority, last, use_ext=False):
    rt = PPMRuntime(initial_value=last)
    # single step from last: need runtime already at last
    rt.state.last_value = last
    rt.state.initialized = True
    d = rt.process(InputSample(value, threshold, Priority(priority)))
    py = {"value": d.value, "delta": d.delta, "protected": d.protected,
          "confidence": d.confidence, "priority": int(d.priority)}
    ora = oracle(value, threshold, priority, last)
    ext = None
    if use_ext:
        import ppm_ext
        e = ppm_ext.Ppm(initial_value=last)
        e.rt.last_value = last  # may not work if opaque
        try:
            ed = e.process(value=value, threshold=threshold, priority=priority)
            ext = ed
        except Exception as ex:
            ext = {"error": str(ex)}
    return {"python": py, "oracle": ora, "ext": ext}

if __name__ == "__main__":
    print("three_way_compare helper — import and use from research scripts")
