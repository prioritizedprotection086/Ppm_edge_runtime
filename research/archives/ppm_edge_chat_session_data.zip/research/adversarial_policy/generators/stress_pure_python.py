#!/usr/bin/env python3
"""Sandbox-only stress experiments against the frozen pure-Python PPMRuntime.
Does NOT modify any repository source. Read-only import of production API.
"""
from __future__ import annotations

import hashlib
import random
import statistics
import sys
import time
from pathlib import Path

ROOT = Path("/home/workdir/artifacts/ppm_edge_runtime_demo_v1")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from ppm_edge.runtime import InputSample, PPMRuntime, Priority, Decision  # noqa: E402


def decision_key(d: Decision) -> str:
    return f"{d.value}|{d.delta}|{d.protected}|{d.confidence}|{int(d.priority)}"


def run_stream(runtime: PPMRuntime, samples: list[InputSample]) -> list[str]:
    return [decision_key(runtime.process(s)) for s in samples]


def make_boundary_heavy(n: int, seed: int = 42) -> list[InputSample]:
    rng = random.Random(seed)
    samples: list[InputSample] = []
    extremes = [
        0, 1, -1,
        2**31 - 1, -(2**31),  # INT32_MAX / INT32_MIN
        2**31 - 2, -(2**31) + 1,
    ]
    thresholds = [0, 1, -1, 20, 1000, 2**31 - 1, -(2**31)]
    priorities = list(Priority)
    for i in range(n):
        if i % 17 == 0:
            v = extremes[i % len(extremes)]
        else:
            v = rng.randint(-(2**31), 2**31 - 1)
        if i % 23 == 0:
            t = thresholds[i % len(thresholds)]
        else:
            t = rng.choice(thresholds)
        if i % 31 == 0:
            p = Priority.CRITICAL
        else:
            p = rng.choice(priorities)
        samples.append(InputSample(value=v, threshold=t, priority=p))
    return samples


def make_smooth(n: int, seed: int = 7) -> list[InputSample]:
    rng = random.Random(seed)
    samples = []
    v = 1000
    for i in range(n):
        delta = rng.randint(-50, 50)
        v = max(-(2**31), min(2**31 - 1, v + delta))
        samples.append(InputSample(value=v, threshold=30, priority=Priority.NORMAL))
    return samples


def fingerprint(keys: list[str]) -> str:
    h = hashlib.sha256()
    for k in keys:
        h.update(k.encode())
        h.update(b"\n")
    return h.hexdigest()[:16]


def timed_run(label: str, n: int, sample_fn, trials: int = 5):
    print(f"\n=== {label}  n={n}  trials={trials} ===")
    throughputs = []
    fps = []
    for t in range(trials):
        samples = sample_fn(n, seed=1000 + t)
        rt = PPMRuntime(initial_value=0)
        t0 = time.perf_counter()
        keys = run_stream(rt, samples)
        elapsed = time.perf_counter() - t0
        fp = fingerprint(keys)
        fps.append(fp)
        rate = n / elapsed if elapsed > 0 else float("inf")
        throughputs.append(rate)
        print(f"  trial {t+1}: {elapsed*1000:.1f} ms  {rate:,.0f} ops/s  fp={fp}")
    # determinism across trials (different seeds => different fp expected;
    # same seed must match)
    same = sample_fn(n, seed=999)
    a = fingerprint(run_stream(PPMRuntime(0), same))
    b = fingerprint(run_stream(PPMRuntime(0), same))
    print(f"  same-seed determinism: {'PASS' if a == b else 'FAIL'}  fp={a}")
    print(f"  mean throughput: {statistics.mean(throughputs):,.0f} ops/s")
    print(f"  stdev: {statistics.stdev(throughputs) if len(throughputs)>1 else 0:,.0f}")
    return throughputs


def long_carryover(n: int = 200_000):
    print(f"\n=== Long carry-over + oracle-style consistency  n={n} ===")
    samples = make_boundary_heavy(n, seed=12345)
    rt = PPMRuntime(initial_value=0)
    t0 = time.perf_counter()
    keys = run_stream(rt, samples)
    elapsed = time.perf_counter() - t0
    print(f"  wall: {elapsed:.3f}s  rate: {n/elapsed:,.0f} ops/s")
    print(f"  final state last_value={rt.state.last_value} initialized={rt.state.initialized}")
    print(f"  fingerprint: {fingerprint(keys)}")

    # second independent run must match exactly
    rt2 = PPMRuntime(initial_value=0)
    keys2 = run_stream(rt2, samples)
    match = keys == keys2
    print(f"  independent re-run match: {'PASS' if match else 'FAIL'}")

    # protected rate
    protected = sum(1 for k in keys if "|True|" in k)
    print(f"  protected decisions: {protected}/{n} ({100*protected/n:.1f}%)")
    return match


def main():
    print("PPM-Edge pure-Python stress experiments (sandbox only, no source mods)")
    print(f"Python {sys.version.split()[0]}")

    # 1) short correctness already covered by unit tests; focus on volume
    timed_run("smooth stream", n=50_000, sample_fn=make_smooth, trials=5)
    timed_run("boundary-heavy stream", n=50_000, sample_fn=make_boundary_heavy, trials=5)

    # 2) longer single run
    ok = long_carryover(200_000)

    # 3) extreme single values
    print("\n=== Extreme single-shot cases ===")
    rt = PPMRuntime(initial_value=0)
    cases = [
        InputSample(0, 0),
        InputSample(2**31 - 1, 0),
        InputSample(-(2**31), 0),
        InputSample(2**31 - 1, 2**31 - 1, Priority.CRITICAL),
        InputSample(-(2**31), -(2**31), Priority.CRITICAL),
        InputSample(1, -1),
        InputSample(-1, 1),
    ]
    for s in cases:
        d = rt.process(s)
        print(f"  in={s.value} th={s.threshold} prio={s.priority.name} -> "
              f"delta={d.delta} prot={d.protected} conf={d.confidence}")

    print("\n=== SUMMARY ===")
    print(f"Long carry-over independent re-run: {'PASS' if ok else 'FAIL'}")
    print("All experiments completed without modifying repository source.")


if __name__ == "__main__":
    main()
