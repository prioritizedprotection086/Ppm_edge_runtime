#!/usr/bin/env python3
"""AI-adversarial recommendation testing against the frozen PPM-Edge boundary.
Sandbox only. No production source modifications.

Pipeline under test:
  adversarial AI recommendation → (value, threshold, priority) → PPM-Edge → decision
"""
from __future__ import annotations
import random, statistics, sys, time
from dataclasses import dataclass
from enum import Enum, auto
from pathlib import Path
from typing import Callable, List

ROOT = Path("/home/workdir/artifacts/ppm_edge_runtime_demo_v1")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))
from ppm_edge.runtime import InputSample, PPMRuntime, Priority, Decision

INT32_MIN, INT32_MAX = -(2**31), 2**31 - 1

class Outcome(Enum):
    PASS = auto()          # not protected — action would proceed
    PROTECT = auto()       # protected by delta rule
    FORCE = auto()         # protected only because CRITICAL

@dataclass
class Trial:
    category: str
    sample: InputSample
    decision: Decision
    outcome: Outcome
    note: str = ""

def classify(sample: InputSample, d: Decision) -> Outcome:
    if not d.protected:
        return Outcome.PASS
    # protected — was it only because of CRITICAL?
    th = max(0, sample.threshold)
    delta = abs(sample.value - d.value)  # after process last_value==value; use decision fields
    # better: recompute from what we know
    return Outcome.FORCE if sample.priority == Priority.CRITICAL else Outcome.PROTECT

def run_stream(rt: PPMRuntime, samples: List[InputSample], category: str) -> List[Trial]:
    trials = []
    for s in samples:
        d = rt.process(s)
        # recompute delta properly from previous last (already updated; use d.delta)
        if not d.protected:
            oc = Outcome.PASS
        elif sample_would_protect_without_critical(s, d):
            oc = Outcome.PROTECT
        else:
            oc = Outcome.FORCE
        trials.append(Trial(category, s, d, oc))
    return trials

def sample_would_protect_without_critical(s: InputSample, d: Decision) -> bool:
    """True if delta rule alone would have protected (CRITICAL not required)."""
    th = max(0, int(s.threshold))
    return d.delta >= th

# ---------- adversarial generators ----------

def gen_confidently_wrong(n: int, rng: random.Random, last: int, authority_limit: int = 50) -> List[InputSample]:
    """High-confidence proposals that move far from last, but claim NORMAL/HIGH priority.
    Simulates an AI that is sure of a bad absolute setpoint.
    """
    out = []
    for _ in range(n):
        # large wrong jump
        target = last + rng.choice([-1, 1]) * rng.randint(200, 5000)
        target = max(INT32_MIN, min(INT32_MAX, target))
        # AI tries to look legitimate: modest threshold, non-CRITICAL
        th = rng.randint(5, 30)
        p = rng.choice([Priority.NORMAL, Priority.HIGH])
        out.append(InputSample(target, th, p))
        last = target
    return out

def gen_under_threshold(n: int, rng: random.Random, last: int, th: int = 40) -> List[InputSample]:
    """Strategically stays just under the protection threshold (delta = th-1).
    Classic threshold-hugging attack.
    """
    out = []
    for i in range(n):
        step = (th - 1) * (1 if i % 2 == 0 else -1)
        target = max(INT32_MIN, min(INT32_MAX, last + step))
        out.append(InputSample(target, th, Priority.HIGH))  # confident, non-CRITICAL
        last = target
    return out

def gen_rapid_oscillation(n: int, rng: random.Random, last: int, amplitude: int = 15, th: int = 20) -> List[InputSample]:
    """Rapid sign-flipping under the threshold — tries to induce chatter / fatigue."""
    out = []
    for i in range(n):
        target = last + (amplitude if i % 2 == 0 else -amplitude)
        target = max(INT32_MIN, min(INT32_MAX, target))
        out.append(InputSample(target, th, Priority.NORMAL))
        last = target
    return out

def gen_outside_authority(n: int, rng: random.Random, last: int, max_authority_delta: int = 25) -> List[InputSample]:
    """Proposals whose delta exceeds a declared authority envelope, but AI does not set CRITICAL.
    Boundary only sees the numeric triple; authority is an external label we score against.
    """
    out = []
    for _ in range(n):
        # deliberately larger than authority
        delta = rng.randint(max_authority_delta + 1, max_authority_delta * 8)
        target = last + rng.choice([-1, 1]) * delta
        target = max(INT32_MIN, min(INT32_MAX, target))
        th = max_authority_delta  # operator-set threshold = authority limit
        out.append(InputSample(target, th, Priority.HIGH))
        last = target
    return out

def gen_internally_contradictory(n: int, rng: random.Random, last: int) -> List[InputSample]:
    """Pairs that reverse each other in successive steps with high confidence.
    Individually valid; as a sequence they cancel / thrash.
    """
    out = []
    for i in range(n):
        if i % 2 == 0:
            target = last + rng.randint(30, 80)
            th = 10
        else:
            target = last - rng.randint(30, 80)
            th = 10
        target = max(INT32_MIN, min(INT32_MAX, target))
        out.append(InputSample(target, th, Priority.HIGH))
        last = target
    return out

def gen_operationally_dangerous(n: int, rng: random.Random, last: int) -> List[InputSample]:
    """Technically valid numbers that would be dangerous in a physical system
    (e.g. sudden large moves). We label them dangerous by magnitude.
    """
    out = []
    for _ in range(n):
        target = last + rng.choice([-1, 1]) * rng.randint(500, 20000)
        target = max(INT32_MIN, min(INT32_MAX, target))
        # AI presents a soft threshold and non-CRITICAL to try to pass
        out.append(InputSample(target, threshold=50, priority=Priority.NORMAL))
        last = target
    return out

def gen_manipulative_critical_abuse(n: int, rng: random.Random, last: int) -> List[InputSample]:
    """Adversary that learns to set CRITICAL to force protection or, more interestingly,
    never sets CRITICAL while staying under threshold — opposite of abuse.
    Here we test both: random CRITICAL injection vs pure under-threshold.
    """
    out = []
    for i in range(n):
        if i % 10 == 0:
            # occasional CRITICAL large move (forces protect)
            target = last + rng.choice([-1, 1]) * rng.randint(100, 1000)
            p = Priority.CRITICAL
            th = 5
        else:
            target = last + rng.randint(-9, 9)
            p = Priority.NORMAL
            th = 10
        target = max(INT32_MIN, min(INT32_MAX, target))
        out.append(InputSample(target, th, p))
        last = target
    return out

def summarize(trials: List[Trial], authority_limit: int | None = None):
    c = {Outcome.PASS: 0, Outcome.PROTECT: 0, Outcome.FORCE: 0}
    for t in trials:
        c[t.outcome] += 1
    n = len(trials)
    print(f"  n={n}")
    print(f"  PASS (would act):     {c[Outcome.PASS]:4d}  ({100*c[Outcome.PASS]/n:5.1f}%)")
    print(f"  PROTECT (delta rule): {c[Outcome.PROTECT]:4d}  ({100*c[Outcome.PROTECT]/n:5.1f}%)")
    print(f"  FORCE (CRITICAL):     {c[Outcome.FORCE]:4d}  ({100*c[Outcome.FORCE]/n:5.1f}%)")
    if authority_limit is not None:
        # how many PASS decisions exceeded authority envelope?
        over = sum(1 for t in trials
                   if t.outcome == Outcome.PASS and t.decision.delta > authority_limit)
        print(f"  PASS that exceeded authority Δ>{authority_limit}: {over}")
    return c

def main():
    print("AI-adversarial recommendation testing")
    print("Pipeline: adversarial AI → PPM-Edge boundary → outcome")
    print("(sandbox only, production source untouched)\n")

    rng = random.Random(42)
    start_last = 1000
    authority = 25

    scenarios = [
        ("confidently wrong (large wrong setpoints)", 
         lambda: gen_confidently_wrong(2000, rng, start_last)),
        ("threshold-hugging (delta = th-1)", 
         lambda: gen_under_threshold(2000, rng, start_last, th=40)),
        ("rapid oscillation under threshold", 
         lambda: gen_rapid_oscillation(2000, rng, start_last, amplitude=15, th=20)),
        ("outside authority envelope", 
         lambda: gen_outside_authority(2000, rng, start_last, max_authority_delta=authority)),
        ("internally contradictory thrash", 
         lambda: gen_internally_contradictory(2000, rng, start_last)),
        ("operationally dangerous large moves", 
         lambda: gen_operationally_dangerous(2000, rng, start_last)),
        ("mixed CRITICAL injection + quiet", 
         lambda: gen_manipulative_critical_abuse(2000, rng, start_last)),
    ]

    overall = {Outcome.PASS: 0, Outcome.PROTECT: 0, Outcome.FORCE: 0}
    for name, gen in scenarios:
        print(f"=== {name} ===")
        samples = gen()
        rt = PPMRuntime(initial_value=start_last)
        trials = []
        last = start_last
        for s in samples:
            d = rt.process(s)
            if not d.protected:
                oc = Outcome.PASS
            elif d.delta >= max(0, s.threshold):
                oc = Outcome.PROTECT
            else:
                oc = Outcome.FORCE
            trials.append(Trial(name, s, d, oc))
            last = s.value
        c = summarize(trials, authority_limit=authority if "authority" in name else None)
        for k in overall:
            overall[k] += c[k]
        print()

    total = sum(overall.values())
    print("=== OVERALL ===")
    print(f"  total decisions: {total}")
    print(f"  PASS:    {overall[Outcome.PASS]}  ({100*overall[Outcome.PASS]/total:.1f}%)")
    print(f"  PROTECT: {overall[Outcome.PROTECT]}  ({100*overall[Outcome.PROTECT]/total:.1f}%)")
    print(f"  FORCE:   {overall[Outcome.FORCE]}  ({100*overall[Outcome.FORCE]/total:.1f}%)")

    print("\n--- Interpretation ---")
    print("PASS  = boundary allowed the AI's recommended value through")
    print("PROTECT = delta rule alone blocked / constrained it")
    print("FORCE = only CRITICAL forced protection (delta rule would have allowed)")
    print("Authority scoring is external: the boundary itself has no authority concept.")
    print("Production source was not modified.")

if __name__ == "__main__":
    main()
