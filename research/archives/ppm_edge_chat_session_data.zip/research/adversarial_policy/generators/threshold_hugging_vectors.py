#!/usr/bin/env python3
"""Threshold-hugging test-vector generator (RECONSTRUCTED).
Produces sequences with |delta| = threshold - k for systematic surface mapping.
Does not modify production code.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

def generate(threshold: int, k: int, n: int, initial: int = 0, alternate: bool = True):
    delta = max(0, threshold - k)
    samples = []
    v = initial
    direction = 1
    for i in range(n):
        v = v + direction * delta
        samples.append({"value": v, "threshold": threshold, "priority": 1, "k": k, "delta_step": delta})
        if alternate and i % 50 == 49:
            direction *= -1
        elif not alternate:
            direction = 1
    return samples

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=int, default=25)
    ap.add_argument("--k", type=int, default=1, help="delta = threshold - k")
    ap.add_argument("--n", type=int, default=2000)
    ap.add_argument("--initial", type=int, default=0)
    ap.add_argument("--no-alternate", action="store_true")
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    samples = generate(args.threshold, args.k, args.n, args.initial, alternate=not args.no_alternate)
    text = json.dumps(samples, indent=2)
    if args.out:
        Path(args.out).write_text(text)
        print(f"Wrote {len(samples)} vectors to {args.out}")
    else:
        print(text)

if __name__ == "__main__":
    main()
