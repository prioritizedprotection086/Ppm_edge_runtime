#!/usr/bin/env python3
"""Multi-seed differential testing of pure-Python PPMRuntime. Read-only."""
from __future__ import annotations
import hashlib, random, sys, time
from pathlib import Path
ROOT = Path("/home/workdir/artifacts/ppm_edge_runtime_demo_v1")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))
from ppm_edge.runtime import InputSample, PPMRuntime, Priority, Decision

def key(d: Decision):
    return (d.value, d.delta, d.protected, d.confidence, int(d.priority))

def make_samples(n, seed, style="mixed"):
    rng = random.Random(seed)
    samples = []
    extremes = [0, 1, -1, 2**31-1, -(2**31), 2**31-2, -(2**31)+1]
    thresholds = [0, 1, -1, 10, 20, 100, 1000, 2**31-1, -(2**31)]
    prios = list(Priority)
    v = 0
    for i in range(n):
        if style == "smooth":
            delta = rng.randint(-40, 40)
            v = max(-(2**31), min(2**31-1, v + delta))
            t, p = 30, Priority.NORMAL
        elif style == "boundary":
            v = extremes[i % len(extremes)] if i % 11 == 0 else rng.randint(-(2**31), 2**31-1)
            t = thresholds[i % len(thresholds)] if i % 7 == 0 else rng.choice(thresholds)
            p = Priority.CRITICAL if i % 29 == 0 else rng.choice(prios)
        else:
            v = extremes[i % len(extremes)] if i % 13 == 0 else rng.randint(-(2**31), 2**31-1)
            t = rng.choice(thresholds)
            p = Priority.CRITICAL if i % 31 == 0 else rng.choice(prios)
        samples.append(InputSample(value=v, threshold=t, priority=p))
    return samples

def run(samples, initial=0):
    rt = PPMRuntime(initial_value=initial)
    return [key(rt.process(s)) for s in samples]

def fp(seq):
    h = hashlib.sha256()
    for item in seq:
        h.update(repr(item).encode()); h.update(b"\n")
    return h.hexdigest()

def main():
    print("Multi-seed differential testing — pure Python PPMRuntime")
    print("(sandbox only, source untouched)\n")
    seeds_small = list(range(20))
    seeds_wide = [0, 1, 7, 42, 99, 123, 999, 12345, 2**31-1, 987654321]
    t0 = time.perf_counter()

    # 1) same-seed determinism
    print("=== Same-seed determinism (n=5000, 20 seeds, 3 styles, 3 repeats) ===")
    fail = 0
    for style in ["smooth", "boundary", "mixed"]:
        for seed in seeds_small:
            seqs = [run(make_samples(5000, seed, style)) for _ in range(3)]
            if not all(s == seqs[0] for s in seqs[1:]):
                fail += 1
                print(f"  FAIL {style} seed={seed}")
    print(f"  result: {'ALL PASS' if fail == 0 else f'{fail} FAILURES'}")
    ok1 = fail == 0

    # 2) cross-seed divergence
    def cross(style, n=10000):
        print(f"\n=== Cross-seed divergence  style={style} n={n} ===")
        fps = {seed: fp(run(make_samples(n, seed, style))) for seed in seeds_wide}
        unique = len(set(fps.values()))
        print(f"  unique fps: {unique}/{len(seeds_wide)}")
        if unique < len(seeds_wide):
            inv = {}
            for s, f in fps.items():
                inv.setdefault(f, []).append(s)
            for f, ss in inv.items():
                if len(ss) > 1:
                    print(f"  collision {f[:12]}... seeds {ss}")
        else:
            print("  no collisions")
        return unique == len(seeds_wide)
    ok2 = cross("mixed")
    ok3 = cross("boundary")

    # 3) initial-value differential
    print("\n=== Initial-value differential n=5000 seed=42 ===")
    samples = make_samples(5000, 42, "mixed")
    initials = [0, 1, -1, 100, -(2**31), 2**31-1, 123456]
    fps = {i: fp(run(samples, i)) for i in initials}
    unique = len(set(fps.values()))
    print(f"  unique fps across {len(initials)} initials: {unique}")
    for i, f in fps.items():
        print(f"    init={i:>12}  fp={f[:16]}...")
    ok4 = unique > 1
    print(f"  diversity: {'PASS' if ok4 else 'FAIL'}")

    # 4) pairwise first difference
    print("\n=== Pairwise first-difference seeds 1 vs 2 (n=2000) ===")
    sa, sb = make_samples(2000, 1, "mixed"), make_samples(2000, 2, "mixed")
    ra, rb = run(sa), run(sb)
    if ra == rb:
        print("  identical (rare)")
    else:
        for i, (a, b) in enumerate(zip(ra, rb)):
            if a != b:
                print(f"  first diff at index {i}")
                print(f"    A: {a}")
                print(f"    B: {b}")
                break

    # 5) protected-rate distribution
    print("\n=== Protected-rate distribution (boundary, n=20000) ===")
    rates = []
    for seed in seeds_wide:
        seq = run(make_samples(20000, seed, "boundary"))
        rates.append(100.0 * sum(1 for t in seq if t[2]) / 20000)
    rates.sort()
    print(f"  min={rates[0]:.1f}%  median={rates[len(rates)//2]:.1f}%  max={rates[-1]:.1f}%  mean={sum(rates)/len(rates):.1f}%")

    # 6) large-n same-seed
    print("\n=== Large-n same-seed (n=100k, 5 seeds, 2 repeats) ===")
    fail = 0
    for s in [11, 22, 33, 44, 55]:
        samples = make_samples(100000, s, "mixed")
        a, b = run(samples), run(samples)
        if a != b:
            fail += 1
            print(f"  FAIL seed={s}")
        else:
            print(f"  seed={s} PASS  fp={fp(a)[:16]}...")
    ok5 = fail == 0

    elapsed = time.perf_counter() - t0
    print(f"\n=== SUMMARY ({elapsed:.1f}s) ===")
    print(f"  same-seed determinism:     {'PASS' if ok1 else 'FAIL'}")
    print(f"  cross-seed (mixed):        {'PASS' if ok2 else 'FAIL'}")
    print(f"  cross-seed (boundary):     {'PASS' if ok3 else 'FAIL'}")
    print(f"  initial-value diversity:   {'PASS' if ok4 else 'FAIL'}")
    print(f"  large-n same-seed:         {'PASS' if ok5 else 'FAIL'}")
    print(f"  overall: {'ALL PASS' if all([ok1,ok2,ok3,ok4,ok5]) else 'SOME FAILURES'}")
    print("  repository source was not modified.")

if __name__ == "__main__":
    main()
