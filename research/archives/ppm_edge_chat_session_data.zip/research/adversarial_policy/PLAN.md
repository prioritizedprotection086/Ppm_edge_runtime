# Experimental Plan — Adversarial Policy Layer

**Status:** In progress on branch `research/adversarial-policy-layer`  
**Constraint:** Do not modify production PPM-Edge implementation.

## Completed (verified in Grok sandbox)

- [x] Determinism / multi-seed differential (Python)
- [x] Long adversarial sequences (Python + standalone C)
- [x] Three-way agreement (Python reference, C kernel, sandbox CPython extension) on in-contract behavior
- [x] Threshold-hugging bypass demonstrated (Δ = th−1 → 0% PROTECT)
- [x] Cumulative unidirectional displacement bypass
- [x] Chatter / rapid oscillation bypass
- [x] Minimal external policy ablation (authority_delta, cum_disp_limit, rate, chatter)
- [x] Red-team bare vs policy on demonstrated attacks
- [x] V1 correctness gates re-run (30/30)

## Next phases

### 1. Threshold-hugging surface (deeper map)
- Systematic grid: thresholds × (threshold−k) for k = 1..th
- Alternating +/− sub-threshold movement
- Cumulative displacement from many individually safe moves
- Vary initial states and sequence lengths (including 100k+)
- Adversarial generator objective: **maximum undesirable cumulative behavior while never triggering protection**
- Save event-by-event vectors + fingerprints

### 2. Attack sequences (not just individual calls)
- Slow drift
- Chatter
- Boundary camping
- Alternating directions
- Contradictory recommendations
- Quiet behavior followed by carefully timed changes
- Combinations of the above
- Record: per-event decisions, cumulative movement, state, protection, confidence, audit fingerprints

### 3. Minimal external policy layer (isolated candidates)
Keep PPM-Edge unchanged. Add controls **one at a time**, only for failures actually demonstrated:
- cumulative displacement limit
- rate / chatter limit
- authority scope
- contradiction detection
- freshness / sequence enforcement  

Measure exactly which demonstrated bypass each control closes and what false-positive rate it introduces.

### 4. Red-team comparison
Compare:
- AI → PPM-Edge  
vs  
- AI → policy layer → PPM-Edge  

Same adversarial generator against both. Measure:
- attacks caught / missed  
- legitimate actions rejected  
- false protections  
- latency overhead  
- deterministic replay  
- recovery  
- Python / C / CPython-extension agreement  

### 5. Hygiene
- Production source stays untouched  
- Capture provenance / source hashes  
- Save raw vectors and raw results  
- Independently repeat important experiments  
- Re-run all V1 correctness gates after changes  
- Label **RECONSTRUCTED** vs recovered original artifacts  

## Labeling
All generators, harnesses, and policy experiments in this tree are **RECONSTRUCTED** in the Grok sandbox from the research direction. They are not the original Claude-sandbox V2/V2.1 artifacts (those were never present in Git).
END

cat > /home/workdir/artifacts/Ppm_edge_runtime/research/adversarial_policy/PROVENANCE.md << 'END'
# Provenance

## Base repository state
- **Remote:** https://github.com/prioritizedprotection086/Ppm_edge_runtime
- **Base commit (branch point):** `38d27b888b6719e2b37bbe2df7391d600de91243` — “Add files via upload”
- **Branch:** `research/adversarial-policy-layer`
- **Production tree at base:** unchanged by this research commit (only `research/` additions)

## Source file hashes (at experiment time)
| Path | sha256[:16] |
|------|-------------|
| `src/ppm_edge/runtime.py` | adb93d09df2c11a1 |
| `Src/Ppm_edge.c` | ba10cee33d6efc1e |
| `Src/Ppm_edge.h` | 5e78e7ecd5ec073e |
| `src/ppm_edge/__init__.py` | 0974fdaadaf44bd2 |
| Sandbox copy `experiments/ext/Ppm_edge.c` | ba10cee33d6efc1e… (full match to Src) |
| Sandbox `ppm_ext` .so | 659886f4b7e9ddbe… |

## Environment
- Platform: Linux (sandbox)
- Python: 3.12.3
- gcc: x86_64-linux-gnu-gcc (extension + C harness builds)
- Git: shallow-capable clone of public repo; full `main` history has 23 commits, **no tags**

## Missing from Git (referenced in V1 docs only)
- Commit `37145182805357a8cc372b3539a3ab7c05fa1f1e` (claimed V1 freeze)
- Commit `235ab5f636b3868fa7bb92987ec74647969ae5ed` (claimed baseline)
- Tag `v1-demo-freeze`
- Original Claude-sandbox V2 / V2.1 artifacts

These were **not recovered**. Any related experimental code in this tree is **RECONSTRUCTED**.

## Experiments actually executed (this sandbox)

| Experiment | Status | Artifact |
|------------|--------|----------|
| V1 `run_tests.py` | 30/30 passed | — |
| V1 demo modes (replay, boundary, live) | PASS / MATCH | — |
| Pure-Python stress (50k–1M) | PASS | generators/stress_pure_python.py |
| Multi-seed differential | ALL PASS | generators/multi_seed_differential.py |
| AI-adversarial boundary battery | completed | generators/ai_adversarial_boundary.py |
| Phase 1 bypass surface | completed | results/phase1_bypass_surface.json |
| Phase 2 adversarial generator | completed | results/phase2_adversarial.json |
| Phase 3 policy ablation | completed | results/phase3_policy_ablation.json |
| Phase 4 red-team bare vs policy | completed | results/phase4_redteam.json |
| Standalone C adversarial harness | ALL PASS | harness/c_harness/adversarial_main.c |
| Three-way Python/C-ext/oracle | ALL PASS | harness/ppm_ext.c |

## Labeling
All research code and results in this directory are **RECONSTRUCTED** (Grok sandbox), not original Claude V2/V2.1 artifacts.
END
echo "PROVENANCE written"