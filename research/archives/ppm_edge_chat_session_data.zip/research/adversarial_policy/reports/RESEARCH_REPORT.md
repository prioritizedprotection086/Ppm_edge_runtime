# Research Report: PPM-Edge Bypass Surface & Minimal Policy Layer

**Date:** 2026-08-16  
**Scope:** Isolated experimental layer only. Production PPM-Edge kernel untouched.  
**Provenance (sha256[:16]):**
- `src/ppm_edge/runtime.py` = adb93d09df2c11a1
- `Src/Ppm_edge.c` = ba10cee33d6efc1e
- sandbox extension so = 659886f4b7e9ddbe

**Evidence discipline:** key experiments run twice independently; V1 gates re-run (30/30); raw JSON under experiments/results/.

---

## 1. How much harmful behavior can currently hide below the threshold?

Under the existing contract (`protected = delta >= threshold OR CRITICAL`):

| Pattern | PROTECT rate | Example scale |
|---------|--------------|---------------|
| Δ = threshold − 1 (hug) | **0%** | 200k steps, path length 4.8M, still 0 protects |
| Δ = threshold − k (k≥1) | **0%** | all tested thresholds 5–100 |
| Unidirectional slow drift at Δ=th−1 | **0%** | 100k steps → net displacement 100k×(th−1) |
| Alternating sub-threshold chatter | **0%** | 20k–50k steps, tens of thousands of reversals |
| Randomized avoid-PROTECT policy | **50/50 seeds full bypass** | path up to ~400k in 10k steps |

**Maximum demonstrated unprotected movement (50k steps, th=50):**
- Path length: **2,450,000**
- Net displacement (slow drift): **2,450,000**
- Reversals (hug/chatter): **49,999**

Initial state does not matter. Sequence length does not accumulate any hidden debt — the rule is memoryless except for `last_value`.

**Verified conclusion:** An adversarial AI that never sets CRITICAL and keeps |Δ| ≤ threshold−1 can produce unbounded cumulative displacement and arbitrary chatter with a 0% PROTECT rate.

---

## 2. Smallest policy layer that closes the demonstrated holes

Mechanisms tested one-at-a-time (external to the kernel):

| Mechanism | Closes slow_drift? | Closes hug/chatter? | False blocks on legitimate small walk? |
|-----------|--------------------|---------------------|----------------------------------------|
| authority_delta (hard \|Δ\| cap) | Yes | Partially (blocks steps > auth) | No (when auth ≥ typical legit step) |
| cum_disp_limit (from origin) | Yes | No (oscillation returns to origin) | No (if limit >> normal range) |
| rate limit (sum \|Δ\| in window) | Yes | Partial | Low if tuned |
| chatter limit (reversals in window) | No | Partial | **High** (false positives on normal walks) |

**Minimal effective set demonstrated:**  
`authority_delta` + `cum_disp_limit`

- slow_drift → 100% blocked (authority or cum_disp)  
- hug/chatter → steps larger than authority blocked; residual oscillation still possible inside the authority band  
- legitimate small walk (Δ≤3) → 0 false blocks with authority=20, cum=500  

Adding chatter limit without careful tuning harms legitimate traffic. Rate limit is useful but not required for the first cut.

---

## 3. New failure modes introduced by the policy layer

1. **Origin dependence (cum_disp):** if the legitimate operating point must move far from the original baseline (e.g., long-running setpoint change), cum_disp will eventually block honest motion unless origin is updated by a higher authority.
2. **Authority floor:** setting authority too tight rejects legitimate fast maneuvers; too loose re-opens slow_drift inside the band.
3. **No semantic understanding:** the layer still cannot see “contradiction,” “wrong goal,” or “manipulative intent” — only numeric envelopes.
4. **Residual in-band attack:** an adversary that stays inside both authority_delta and cum_disp_limit can still chatter or drift slowly within that box.

---

## 4. What remains fundamentally outside PPM-Edge’s scope

- Intent, contradiction, authority *labels*, world models, task constraints  
- Any property that cannot be reduced to (value, threshold, priority) or simple functions of recent numeric history  
- Deciding whether a sub-threshold move is “good” or “bad” for the robot’s mission  

PPM-Edge is a **fast, deterministic numeric gate**, not a planner or a value-alignment system.

---

## 5. Implications for AI planner → physical robot

The architecture is useful as a **last numeric safety interlock**:

- It reliably stops gross, blunt, or incompetent large moves when threshold is set to the real physical/authority envelope.  
- It does **not** stop a capable adversarial or simply optimizing AI that respects the numeric envelope while still being wrong.  

Therefore:

1. Keep PPM-Edge thin, fast, and verified (current state is good).  
2. Put a small, explicit policy layer *above* it for cumulative displacement and hard authority caps.  
3. Treat anything requiring semantics (contradiction, goal appropriateness, long-horizon harm) as a separate, slower layer — not as an extension of this kernel.  
4. Never rely on the boundary alone against an AI that can read the rule.

**Bottom line:** PPM-Edge is a trustworthy calculator of a simple rule. The demonstrated bypasses are not bugs in that rule; they are the rule working exactly as specified. Closing the robotics-relevant holes requires policy above the kernel, not a smarter kernel.

---

## Evidence index
- experiments/results/phase1_bypass_surface.json  
- experiments/results/phase2_adversarial.json  
- experiments/results/phase3_policy_ablation.json  
- experiments/results/phase4_redteam.json  
- V1 gates after all experiments: 30/30 passed  
- Independent re-runs: long hug, best-path attack, red-team modes — matched  
