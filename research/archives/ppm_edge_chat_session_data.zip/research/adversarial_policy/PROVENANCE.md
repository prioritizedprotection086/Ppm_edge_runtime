# Provenance

## Base repository state
- **Remote:** https://github.com/prioritizedprotection086/Ppm_edge_runtime
- **Base commit (branch point):** `38d27b888b6719e2b37bbe2df7391d600de91243` — "Add files via upload"
- **Branch:** `research/adversarial-policy-layer`
- **Production tree:** unchanged (only additions under `research/`)

## Source file hashes (experiment time)
| Path | sha256[:16] |
|------|-------------|
| `src/ppm_edge/runtime.py` | adb93d09df2c11a1 |
| `Src/Ppm_edge.c` | ba10cee33d6efc1e |
| `Src/Ppm_edge.h` | 5e78e7ecd5ec073e |
| `src/ppm_edge/__init__.py` | 0974fdaadaf44bd2 |
| Sandbox extension `.so` | 659886f4b7e9ddbe |

## Environment
- Platform: Linux sandbox
- Python: 3.12.3
- gcc: x86_64-linux-gnu-gcc
- Git history on `main`: 23 commits, **zero tags**

## Missing from Git (docs only; not recovered)
- `37145182805357a8cc372b3539a3ab7c05fa1f1e`
- `235ab5f636b3868fa7bb92987ec74647969ae5ed`
- Tag `v1-demo-freeze`
- Original Claude V2 / V2.1 sandbox artifacts

## Experiments executed
| Experiment | Result | Artifact |
|------------|--------|----------|
| V1 run_tests.py | 30/30 | — |
| Demo replay/boundary/live | PASS | — |
| Pure-Python stress | PASS | generators/stress_pure_python.py |
| Multi-seed differential | ALL PASS | generators/multi_seed_differential.py |
| AI-adversarial boundary | completed | generators/ai_adversarial_boundary.py |
| Phase 1 bypass surface | completed | results/phase1_bypass_surface.json |
| Phase 2 adversarial | completed | results/phase2_adversarial.json |
| Phase 3 policy ablation | completed | results/phase3_policy_ablation.json |
| Phase 4 red-team | completed | results/phase4_redteam.json |
| C adversarial harness | ALL PASS | harness/c_harness/ |
| Three-way Python/ext/oracle | ALL PASS | harness/ppm_ext.c |

## Labeling
All research code/results here are **RECONSTRUCTED** (Grok sandbox), not original Claude V2/V2.1 artifacts.
