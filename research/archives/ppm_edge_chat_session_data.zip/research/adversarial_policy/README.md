# Adversarial Policy Layer Research

**Branch:** `research/adversarial-policy-layer`  
**Status:** Experimental — production PPM-Edge kernel is untouched  
**Base commit:** `38d27b888b6719e2b37bbe2df7391d600de91243`

## Research question

Can a sequence of individually valid inputs manipulate PPM-Edge state into an outcome that violates the declared contract? More broadly: does the architecture remain an effective separation between an unpredictable AI decision-maker and physical action when the AI is wrong, manipulated, or operating under conflicting objectives?

## Verified findings

### Determinism and contract correctness
- Python reference, C kernel, and a sandbox CPython extension **agree** on in-contract behavior.
- Same-seed determinism: **PASS** (multi-style, multi-seed, including n=100k).
- Adversarial sequences of valid inputs **cannot** drive the kernel into a contract-illegal outcome.
- V1 correctness gates: **30/30 passed** after all experiments.

### Important weakness (verified)
An adversarial AI can stay just below the threshold indefinitely:
- Any sequence with `|Δ| ≤ threshold−1` and never `CRITICAL` has **0% PROTECT** rate.
- Demonstrated at 200k steps (path length 4.8M) with full bypass.
- Slow drift accumulates unbounded net displacement without ever triggering protection.
- Rapid sub-threshold oscillation (chatter) passes completely.
- Randomized avoid-PROTECT policies: **50/50 seeds** fully bypassed.

### Minimal external policy layer (experimental, not production)
Candidate controls evaluated one at a time against demonstrated bypasses only:

| Mechanism | Closes slow_drift | Closes hug/chatter | False positives on legit small walk |
|-----------|-------------------|--------------------|-------------------------------------|
| `authority_delta` | Yes | Partial | No (if auth ≥ typical step) |
| `cum_disp_limit` | Yes | No | No (if limit ≫ normal range) |
| rate limit | Yes | Partial | Low if tuned |
| chatter limit | No | Partial | **High** |

**Minimal set that closes demonstrated holes:** `authority_delta` + `cum_disp_limit` above an unchanged kernel.

### New tradeoffs introduced
- Origin dependence (cum_disp blocks honest long setpoint moves unless origin is updated).
- Authority tuning tradeoff (too tight vs too loose).
- Residual in-band attacks that stay inside both caps.
- Still no semantics (intent, contradiction, goal appropriateness).

### What remains outside PPM-Edge scope
Intent, contradiction, world models, task constraints — anything that does not reduce to the numeric triple or simple delta history.

## Artifact labeling

| Artifact | Label |
|----------|-------|
| V1 demo package (zip contents, DEMO_*, MASTER_SESSION_RECORD) | Present on `main` as zip snapshot |
| Commits `37145182…`, `235ab5f6…`, tag `v1-demo-freeze` | **MISSING from Git** (referenced in docs only) |
| V2 / V2.1 research artifacts from Claude sandbox | **MISSING** — not recovered |
| Experimental generators, harness, policy ablations, reports in this tree | **RECONSTRUCTED** in Grok sandbox from research direction, not original Claude artifacts |

## How to reproduce

```bash
# From repo root (this branch)
cd research/adversarial_policy

# V1 gates (production tree)
cd ../..   # repo root
# extract or use demo package if present:
# python3 run_tests.py   # from extracted V1 demo package

# Phase generators (from research/adversarial_policy or sandbox experiments/)
python3 generators/stress_pure_python.py
python3 generators/multi_seed_differential.py
python3 generators/ai_adversarial_boundary.py

# C harness (requires gcc)
cd harness/c_harness
gcc -O2 -o /tmp/adv adversarial_main.c Ppm_edge.c -I.
/tmp/adv

# Extension (optional three-way)
cd ../   # harness/
python3 setup.py build_ext --inplace
```

## Directory layout

```
research/adversarial_policy/
  README.md          — this file
  PLAN.md            — next experimental phases
  PROVENANCE.md      — hashes, commits, environment, executed experiments
  generators/        — adversarial & stress generators (RECONSTRUCTED)
  harness/           — C harness + optional CPython extension wrapper (RECONSTRUCTED)
  policy_layers/     — isolated candidate policy controls (RECONSTRUCTED)
  results/           — raw JSON from completed experiments
  reports/           — verified findings
```

## What is NOT in this branch
- No changes to `Src/`, `src/`, production tests, or CI
- No claim that V2/V2.1 Claude-sandbox artifacts were recovered (they were not present in Git)
- No push of reconstructed freeze commits as if they were original
END
