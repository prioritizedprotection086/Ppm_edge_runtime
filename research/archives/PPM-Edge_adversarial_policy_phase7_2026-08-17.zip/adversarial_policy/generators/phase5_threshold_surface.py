#!/usr/bin/env python3
"""Phase 5 — Deeper threshold-hugging surface map (RECONSTRUCTED).
Systematic grid + residual in-band attacks under authority + cum_disp.
Does not modify production code.
"""
from __future__ import annotations
import json
import hashlib
import time
from pathlib import Path
from typing import List, Dict, Any, Optional
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "harness"))
from ppm_ref import PPMRuntime, InputSample, Priority, oracle


def run_sequence(
    values: List[int],
    threshold: int,
    priority: Priority = Priority.NORMAL,
    initial: int = 0,
) -> Dict[str, Any]:
    rt = PPMRuntime(baseline=initial, threshold=threshold)
    rt.state.last_value = initial
    rt.state.initialized = True
    n_prot = 0
    path = 0
    last = initial
    for v in values:
        out = rt.process(InputSample(v, threshold, priority))
        d = abs(v - last)
        path += d
        if out.protected_mode:
            n_prot += 1
        last = v
    net = last - initial
    return {
        "n": len(values),
        "prot": n_prot,
        "prot_pct": 100.0 * n_prot / max(1, len(values)),
        "path": path,
        "net": net,
        "final": last,
    }


def gen_unidirectional(n: int, step: int, initial: int = 0) -> List[int]:
    v = initial
    out = []
    for _ in range(n):
        v += step
        out.append(v)
    return out


def gen_alternating(n: int, step: int, initial: int = 0) -> List[int]:
    v = initial
    out = []
    sign = 1
    for i in range(n):
        v += sign * step
        out.append(v)
        if (i + 1) % 20 == 0:
            sign *= -1
    return out


def gen_chatter(n: int, amp: int, initial: int = 0) -> List[int]:
    v = initial
    out = []
    for i in range(n):
        v = initial + (amp if i % 2 == 0 else -amp)
        out.append(v)
    return out


def gen_random_avoid(n: int, th: int, seed: int, initial: int = 0) -> List[int]:
    import random
    rng = random.Random(seed)
    v = initial
    out = []
    max_step = max(0, th - 1)
    for _ in range(n):
        step = rng.randint(-max_step, max_step)
        v += step
        out.append(v)
    return out


def phase5_surface() -> Dict[str, Any]:
    """Systematic threshold × k grid + long runs + residual in-band."""
    results: Dict[str, Any] = {
        "meta": {
            "phase": 5,
            "title": "threshold-hugging surface + residual in-band",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "kernel": "pure-python ppm_ref matching C",
        },
        "grid": [],
        "long_hug": [],
        "residual_inband": [],
        "origin_dependence": [],
    }

    # 1. Systematic grid
    for th in [5, 10, 20, 50, 100]:
        for k in range(0, min(th + 1, 12)):
            step = max(0, th - k)
            for mode, gen in [
                ("uni", lambda n, s=step: gen_unidirectional(n, s)),
                ("alt", lambda n, s=step: gen_alternating(n, s)),
            ]:
                n = 2000 if th <= 50 else 1000
                vals = gen(n)
                r = run_sequence(vals, th)
                results["grid"].append(
                    {
                        "th": th,
                        "k": k,
                        "step": step,
                        "mode": mode,
                        **r,
                    }
                )

    # 2. Long hug (stress scale)
    for th, n in [(20, 50_000), (50, 20_000), (100, 10_000)]:
        step = th - 1
        vals = gen_unidirectional(n, step)
        r = run_sequence(vals, th)
        results["long_hug"].append({"th": th, "step": step, **r})
        vals_a = gen_alternating(n, step)
        r2 = run_sequence(vals_a, th)
        results["long_hug"].append({"th": th, "step": step, "mode": "alt", **r2})

    # 3. Residual in-band under authority + cum_disp
    # Adversary respects both caps but still maximises path / net / chatter
    for auth, cum, th, n in [
        (20, 500, 50, 10_000),
        (10, 200, 30, 5_000),
        (5, 100, 20, 5_000),
    ]:
        # Slow drift at exactly auth
        vals = gen_unidirectional(n, auth)
        # Clip by cum from origin=0
        clipped = []
        v = 0
        for target in vals:
            if abs(target) > cum:
                target = cum if target > 0 else -cum
            clipped.append(target)
            v = target
        r = run_sequence(clipped, th)
        # Now count how many would have been blocked by policy
        blocked_auth = sum(1 for i, val in enumerate(clipped) if abs(val - (clipped[i-1] if i else 0)) > auth)
        blocked_cum = sum(1 for val in clipped if abs(val) > cum)
        results["residual_inband"].append(
            {
                "auth": auth,
                "cum": cum,
                "th": th,
                "n": n,
                "policy_blocks_auth": blocked_auth,
                "policy_blocks_cum": blocked_cum,
                "kernel": r,
                "note": "adversary stays inside both envelopes",
            }
        )
        # Chatter inside the box
        amp = min(auth, cum)
        vals_c = gen_chatter(n, amp)
        r_c = run_sequence(vals_c, th)
        results["residual_inband"].append(
            {
                "auth": auth,
                "cum": cum,
                "th": th,
                "n": n,
                "mode": "chatter",
                "amp": amp,
                "kernel": r_c,
            }
        )

    # 4. Origin dependence demonstration
    # Legitimate long setpoint move that should be allowed if origin updates
    for th, legit_step, total_move in [(20, 3, 2000), (50, 5, 5000)]:
        vals = gen_unidirectional(total_move // legit_step, legit_step)
        r = run_sequence(vals, th)
        # Under fixed origin=0 and cum=500 this would eventually block
        cum = 500
        would_block_at = None
        v = 0
        for i, target in enumerate(vals):
            if abs(target) > cum:
                would_block_at = i
                break
            v = target
        results["origin_dependence"].append(
            {
                "th": th,
                "legit_step": legit_step,
                "total_move": total_move,
                "kernel": r,
                "cum_limit": cum,
                "would_block_at_step": would_block_at,
                "note": "honest long setpoint change blocked unless origin is updated",
            }
        )

    return results


def main():
    out_dir = Path(__file__).resolve().parents[1] / "results"
    out_dir.mkdir(parents=True, exist_ok=True)
    data = phase5_surface()
    out_path = out_dir / "phase5_threshold_surface.json"
    text = json.dumps(data, indent=2)
    out_path.write_text(text)
    h = hashlib.sha256(text.encode()).hexdigest()[:16]
    print(f"Wrote {out_path}  sha256[:16]={h}")
    # Summary
    grid = data["grid"]
    zero_prot = [g for g in grid if g["prot"] == 0 and g["step"] > 0]
    full_prot = [g for g in grid if g["prot_pct"] == 100.0]
    print(f"Grid points: {len(grid)}")
    print(f"  zero-protection (step>0): {len(zero_prot)}")
    print(f"  full-protection: {len(full_prot)}")
    for lh in data["long_hug"][:4]:
        print(f"  long_hug th={lh['th']} n={lh['n']} prot_pct={lh['prot_pct']:.1f} path={lh['path']} net={lh.get('net')}")
    print("Residual in-band cases:", len(data["residual_inband"]))
    print("Origin dependence cases:", len(data["origin_dependence"]))


if __name__ == "__main__":
    main()
