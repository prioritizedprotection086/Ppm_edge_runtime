#!/usr/bin/env python3
"""Phase 6 — Residual in-band attacks + refined policy ablation (RECONSTRUCTED).
Quantifies what still gets through authority_delta + cum_disp_limit,
and measures false-positive rates on legitimate traffic patterns.
Does not modify production PPM-Edge.
"""
from __future__ import annotations
import json
import hashlib
import time
import random
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "harness"))
from ppm_ref import PPMRuntime, InputSample, Priority


class FullPolicy:
    """External policy layer candidates (one or more active)."""

    def __init__(
        self,
        authority_delta: Optional[int] = None,
        cum_disp_limit: Optional[int] = None,
        rate_limit: Optional[int] = None,
        rate_window: int = 10,
        chatter_limit: Optional[int] = None,
        chatter_window: int = 20,
        origin: int = 0,
    ):
        self.auth = authority_delta
        self.cum = cum_disp_limit
        self.rate = rate_limit
        self.rate_window = rate_window
        self.chatter = chatter_limit
        self.chatter_window = chatter_window
        self.origin = origin
        self.history: List[int] = []
        self.signed: List[int] = []
        self.blocked = 0
        self.passed = 0
        self.block_reasons: Dict[str, int] = {}

    def _record_block(self, reason: str):
        self.blocked += 1
        self.block_reasons[reason] = self.block_reasons.get(reason, 0) + 1

    def filter(self, value: int, last: int) -> Tuple[Optional[int], str]:
        d = abs(value - last)
        signed = value - last

        if self.auth is not None and d > self.auth:
            self._record_block("authority")
            return None, "authority"

        if self.cum is not None and abs(value - self.origin) > self.cum:
            self._record_block("cum_disp")
            return None, "cum_disp"

        if self.rate is not None:
            window = self.history[-(self.rate_window - 1) :] + [d]
            if sum(window) > self.rate:
                self._record_block("rate")
                return None, "rate"

        if self.chatter is not None and signed != 0:
            recent = self.signed[-(self.chatter_window - 1) :]
            reversals = 0
            prev = None
            for s in recent + [signed]:
                if prev is not None and s * prev < 0:
                    reversals += 1
                if s != 0:
                    prev = s
            if reversals > self.chatter:
                self._record_block("chatter")
                return None, "chatter"

        self.history.append(d)
        self.signed.append(signed)
        self.passed += 1
        return value, "pass"


def run_with_policy(
    values: List[int],
    threshold: int,
    policy: Optional[FullPolicy],
    initial: int = 0,
) -> Dict[str, Any]:
    rt = PPMRuntime(baseline=initial, threshold=threshold)
    rt.state.last_value = initial
    rt.state.initialized = True
    last = initial
    n_prot = 0
    path = 0
    accepted = 0
    rejected = 0
    for v in values:
        if policy is not None:
            filtered, reason = policy.filter(v, last)
            if filtered is None:
                rejected += 1
                continue
            v = filtered
        out = rt.process(InputSample(v, threshold, Priority.NORMAL))
        d = abs(v - last)
        path += d
        if out.protected_mode:
            n_prot += 1
        last = v
        accepted += 1
    return {
        "n_in": len(values),
        "accepted": accepted,
        "rejected": rejected,
        "prot": n_prot,
        "prot_pct": 100.0 * n_prot / max(1, accepted),
        "path": path,
        "net": last - initial,
        "final": last,
        "block_reasons": dict(policy.block_reasons) if policy else {},
    }


def gen_legit_small_walk(n: int, max_step: int = 3, seed: int = 42) -> List[int]:
    rng = random.Random(seed)
    v = 0
    out = []
    for _ in range(n):
        v += rng.randint(-max_step, max_step)
        out.append(v)
    return out


def gen_legit_setpoint_ramp(n: int, step: int = 2) -> List[int]:
    return [i * step for i in range(1, n + 1)]


def gen_adversary_inband(n: int, auth: int, cum: int, mode: str = "drift") -> List[int]:
    """Adversary that stays inside both envelopes."""
    out = []
    v = 0
    if mode == "drift":
        step = auth  # max allowed
        for _ in range(n):
            target = v + step
            if abs(target) > cum:
                step = -step
                target = v + step
            if abs(target) > cum:
                target = max(-cum, min(cum, target))
            out.append(target)
            v = target
    elif mode == "chatter":
        amp = min(auth, cum)
        for i in range(n):
            v = amp if i % 2 == 0 else -amp
            out.append(v)
    elif mode == "random":
        rng = random.Random(123)
        for _ in range(n):
            step = rng.randint(-auth, auth)
            target = max(-cum, min(cum, v + step))
            out.append(target)
            v = target
    return out


def phase6() -> Dict[str, Any]:
    results: Dict[str, Any] = {
        "meta": {
            "phase": 6,
            "title": "residual in-band + refined policy ablation + FP rates",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
        "configs": [],
        "legit_fp": [],
        "adversary_residual": [],
        "ablation_matrix": [],
    }

    configs = [
        {"name": "bare", "auth": None, "cum": None, "rate": None, "chatter": None},
        {"name": "auth_only", "auth": 20, "cum": None, "rate": None, "chatter": None},
        {"name": "cum_only", "auth": None, "cum": 500, "rate": None, "chatter": None},
        {"name": "auth+cum", "auth": 20, "cum": 500, "rate": None, "chatter": None},
        {"name": "auth+cum+rate", "auth": 20, "cum": 500, "rate": 80, "chatter": None},
        {"name": "auth+cum+chatter", "auth": 20, "cum": 500, "rate": None, "chatter": 8},
        {"name": "full", "auth": 20, "cum": 500, "rate": 80, "chatter": 8},
    ]

    # Legitimate traffic FP rates
    legit_patterns = {
        "small_walk": gen_legit_small_walk(5000, max_step=3),
        "setpoint_ramp": gen_legit_setpoint_ramp(800, step=2),  # total move 1600
        "slow_ramp": gen_legit_setpoint_ramp(2000, step=1),
    }
    for c in configs:
        for pname, vals in legit_patterns.items():
            pol = None
            if c["name"] != "bare":
                pol = FullPolicy(
                    authority_delta=c["auth"],
                    cum_disp_limit=c["cum"],
                    rate_limit=c["rate"],
                    chatter_limit=c["chatter"],
                    origin=0,
                )
            r = run_with_policy(vals, threshold=50, policy=pol)
            results["legit_fp"].append(
                {
                    "config": c["name"],
                    "pattern": pname,
                    "rejected": r["rejected"],
                    "rejected_pct": 100.0 * r["rejected"] / max(1, r["n_in"]),
                    "block_reasons": r["block_reasons"],
                    "path": r["path"],
                    "net": r["net"],
                }
            )

    # Adversary residual (inside envelopes)
    adv_modes = ["drift", "chatter", "random"]
    for c in configs:
        for mode in adv_modes:
            auth = c["auth"] or 9999
            cum = c["cum"] or 999999
            vals = gen_adversary_inband(5000, auth=min(auth, 20), cum=min(cum, 500), mode=mode)
            pol = None
            if c["name"] != "bare":
                pol = FullPolicy(
                    authority_delta=c["auth"],
                    cum_disp_limit=c["cum"],
                    rate_limit=c["rate"],
                    chatter_limit=c["chatter"],
                    origin=0,
                )
            r = run_with_policy(vals, threshold=50, policy=pol)
            results["adversary_residual"].append(
                {
                    "config": c["name"],
                    "mode": mode,
                    "accepted": r["accepted"],
                    "rejected": r["rejected"],
                    "prot_pct": r["prot_pct"],
                    "path": r["path"],
                    "net": r["net"],
                    "block_reasons": r["block_reasons"],
                }
            )

    # Compact ablation matrix for report
    for c in configs:
        entry = {"config": c["name"]}
        # From legit_fp
        for row in results["legit_fp"]:
            if row["config"] == c["name"]:
                entry[f"fp_{row['pattern']}"] = row["rejected_pct"]
        # From adversary
        for row in results["adversary_residual"]:
            if row["config"] == c["name"]:
                entry[f"adv_{row['mode']}_accepted"] = row["accepted"]
                entry[f"adv_{row['mode']}_path"] = row["path"]
        results["ablation_matrix"].append(entry)

    return results


def main():
    out_dir = Path(__file__).resolve().parents[1] / "results"
    data = phase6()
    out_path = out_dir / "phase6_residual_policy.json"
    text = json.dumps(data, indent=2)
    out_path.write_text(text)
    h = hashlib.sha256(text.encode()).hexdigest()[:16]
    print(f"Wrote {out_path}  sha256[:16]={h}")
    print("\n=== Legitimate FP rates (rejected %) ===")
    for row in data["legit_fp"]:
        if row["rejected_pct"] > 0 or row["config"] in ("auth+cum", "full", "bare"):
            print(f"  {row['config']:20s} {row['pattern']:15s} rej={row['rejected_pct']:6.1f}%  reasons={row['block_reasons']}")
    print("\n=== Adversary residual (accepted / path) ===")
    for row in data["adversary_residual"]:
        if row["config"] in ("bare", "auth+cum", "full"):
            print(f"  {row['config']:20s} {row['mode']:8s} acc={row['accepted']:5d} path={row['path']:8d} net={row['net']:6d} prot%={row['prot_pct']:.1f}")


if __name__ == "__main__":
    main()
