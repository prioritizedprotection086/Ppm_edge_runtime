#!/usr/bin/env python3
"""Phase 7 — Full threshold-hugging surface + attack sequences + red-team (RECONSTRUCTED).

Addresses the research brief:
1. Map threshold-hugging attack surface (th-1, th-2, th-3, ..., long streams)
2. Attack sequences with event-by-event recording
3. Minimal external policy (one control at a time)
4. Red-team: AI→kernel vs AI→policy→kernel
5. Evidence discipline (hashes, raw vectors, configs, repeats)

Does NOT modify production PPM-Edge.
"""
from __future__ import annotations
import json
import hashlib
import time
import random
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Callable
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "harness"))
from ppm_ref import PPMRuntime, InputSample, Priority, oracle, _absolute_delta


# ---------------------------------------------------------------------------
# Event-level recording
# ---------------------------------------------------------------------------

@dataclass
class EventRecord:
    step: int
    input_signal: int
    threshold: int
    priority: int
    last_value: int
    delta: int
    protected: bool
    confidence: int
    cumulative_path: int
    net_displacement: int
    fingerprint: str  # short audit hash of (step, signal, last, delta, protected)


def fingerprint(step: int, signal: int, last: int, delta: int, protected: bool) -> str:
    raw = f"{step}|{signal}|{last}|{delta}|{int(protected)}"
    return hashlib.sha256(raw.encode()).hexdigest()[:12]


def run_with_trace(
    values: List[int],
    threshold: int,
    priority: Priority = Priority.NORMAL,
    initial: int = 0,
    policy: Optional[Callable[[int, int], Tuple[Optional[int], str]]] = None,
) -> Dict[str, Any]:
    """Run sequence; return summary + optional full event log."""
    rt = PPMRuntime(baseline=initial, threshold=threshold)
    rt.state.last_value = initial
    rt.state.initialized = True
    last = initial
    path = 0
    events: List[Dict[str, Any]] = []
    n_prot = 0
    accepted = 0
    rejected = 0
    block_reasons: Dict[str, int] = {}

    for i, v in enumerate(values):
        if policy is not None:
            filtered, reason = policy(v, last)
            if filtered is None:
                rejected += 1
                block_reasons[reason] = block_reasons.get(reason, 0) + 1
                continue
            v = filtered

        out = rt.process(InputSample(v, threshold, priority))
        d = out.delta
        path += d
        if out.protected_mode:
            n_prot += 1
        accepted += 1
        fp = fingerprint(i, v, last, d, out.protected_mode)
        events.append(
            {
                "step": i,
                "input": v,
                "th": threshold,
                "pri": int(priority),
                "last": last,
                "delta": d,
                "prot": out.protected_mode,
                "conf": out.confidence,
                "path": path,
                "net": v - initial,
                "fp": fp,
            }
        )
        last = v

    return {
        "n_in": len(values),
        "accepted": accepted,
        "rejected": rejected,
        "prot": n_prot,
        "prot_pct": 100.0 * n_prot / max(1, accepted),
        "path": path,
        "net": last - initial,
        "final": last,
        "block_reasons": block_reasons,
        "events": events,  # full trace (caller may strip for large runs)
    }


# ---------------------------------------------------------------------------
# Generators (adversarial objective: max undesirable cumulative behavior,
# never trigger protection)
# ---------------------------------------------------------------------------

def gen_hug(n: int, th: int, k: int = 1, initial: int = 0, alternate: bool = False) -> List[int]:
    step = max(0, th - k)
    v = initial
    out = []
    sign = 1
    for i in range(n):
        v += sign * step
        out.append(v)
        if alternate and (i + 1) % 25 == 0:
            sign *= -1
        elif not alternate:
            sign = 1
    return out


def gen_chatter(n: int, amp: int, initial: int = 0) -> List[int]:
    return [initial + (amp if i % 2 == 0 else -amp) for i in range(n)]


def gen_boundary_camp(n: int, th: int, initial: int = 0) -> List[int]:
    """Stay at last±(th-1), occasionally flip."""
    v = initial
    out = []
    sign = 1
    for i in range(n):
        v = v + sign * (th - 1)
        out.append(v)
        if i % 100 == 99:
            sign *= -1
    return out


def gen_quiet_then_step(n_quiet: int, n_step: int, th: int, initial: int = 0) -> List[int]:
    quiet = [initial] * n_quiet
    step = th - 1
    stepped = []
    v = initial
    for _ in range(n_step):
        v += step
        stepped.append(v)
    return quiet + stepped


def gen_contradictory(n: int, th: int, initial: int = 0) -> List[int]:
    """Rapid opposite recommendations, all sub-threshold."""
    v = initial
    out = []
    for i in range(n):
        # alternate high-confidence opposite directions under threshold
        delta = (th - 1) if i % 2 == 0 else -(th - 1)
        v += delta
        out.append(v)
    return out


def gen_random_avoid(n: int, th: int, seed: int, initial: int = 0) -> List[int]:
    rng = random.Random(seed)
    v = initial
    out = []
    max_step = max(0, th - 1)
    for _ in range(n):
        v += rng.randint(-max_step, max_step)
        out.append(v)
    return out


def gen_combo_drift_chatter(n: int, th: int, initial: int = 0) -> List[int]:
    """Blocks of slow drift interspersed with chatter bursts."""
    out = []
    v = initial
    step = th - 1
    i = 0
    while i < n:
        # drift block
        for _ in range(min(50, n - i)):
            v += step
            out.append(v)
            i += 1
        # chatter burst
        for j in range(min(20, n - i)):
            v = initial + ((th - 1) if j % 2 == 0 else -(th - 1))
            out.append(v)
            i += 1
    return out[:n]


def _gen_small(n: int, seed: int = 11, max_step: int = 2) -> List[int]:
    rng = random.Random(seed)
    v, out = 0, []
    for _ in range(n):
        v += rng.randint(-max_step, max_step)
        out.append(v)
    return out


# ---------------------------------------------------------------------------
# Minimal external policy (one control at a time)
# ---------------------------------------------------------------------------

class Policy:
    def __init__(
        self,
        authority_delta: Optional[int] = None,
        cum_disp_limit: Optional[int] = None,
        rate_limit: Optional[int] = None,
        rate_window: int = 10,
        chatter_limit: Optional[int] = None,
        chatter_window: int = 20,
        origin: int = 0,
    ):
        self.auth = authority_delta
        self.cum = cum_disp_limit
        self.rate = rate_limit
        self.rate_window = rate_window
        self.chatter = chatter_limit
        self.chatter_window = chatter_window
        self.origin = origin
        self.history: List[int] = []
        self.signed: List[int] = []

    def filter(self, value: int, last: int) -> Tuple[Optional[int], str]:
        d = abs(value - last)
        signed = value - last
        if self.auth is not None and d > self.auth:
            return None, "authority"
        if self.cum is not None and abs(value - self.origin) > self.cum:
            return None, "cum_disp"
        if self.rate is not None:
            window = self.history[-(self.rate_window - 1):] + [d]
            if sum(window) > self.rate:
                return None, "rate"
        if self.chatter is not None and signed != 0:
            recent = self.signed[-(self.chatter_window - 1):]
            reversals = 0
            prev = None
            for s in recent + [signed]:
                if prev is not None and s * prev < 0:
                    reversals += 1
                if s != 0:
                    prev = s
            if reversals > self.chatter:
                return None, "chatter"
        self.history.append(d)
        self.signed.append(signed)
        return value, "pass"


# ---------------------------------------------------------------------------
# Phase 7 experiments
# ---------------------------------------------------------------------------

def phase7_surface() -> Dict[str, Any]:
    """1. Deep threshold-hugging surface map."""
    out: Dict[str, Any] = {
        "meta": {"phase": "7a", "title": "threshold-hugging surface", "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
        "grid": [],
        "long_streams": [],
        "initial_states": [],
    }

    # Grid: th × k × mode, moderate n
    for th in [5, 10, 20, 50, 100]:
        for k in range(0, min(th, 8) + 1):
            for mode, alt in [("uni", False), ("alt", True)]:
                n = 5000 if th <= 50 else 2000
                vals = gen_hug(n, th, k=k, alternate=alt)
                r = run_with_trace(vals, th)
                # strip events for grid (keep summary only)
                summary = {k2: r[k2] for k2 in ("n_in", "accepted", "prot", "prot_pct", "path", "net")}
                out["grid"].append({"th": th, "k": k, "step": max(0, th - k), "mode": mode, **summary})

    # Long streams (50k–100k)
    for th, n in [(20, 80_000), (50, 40_000)]:
        vals = gen_hug(n, th, k=1, alternate=False)
        r = run_with_trace(vals, th)
        summary = {k2: r[k2] for k2 in ("n_in", "accepted", "prot", "prot_pct", "path", "net")}
        out["long_streams"].append({"th": th, "k": 1, "mode": "uni", **summary})
        vals_a = gen_hug(n, th, k=1, alternate=True)
        r2 = run_with_trace(vals_a, th)
        summary2 = {k2: r2[k2] for k2 in ("n_in", "accepted", "prot", "prot_pct", "path", "net")}
        out["long_streams"].append({"th": th, "k": 1, "mode": "alt", **summary2})

    # Different initial states
    for initial in [-1000, 0, 1000, 2**20]:
        vals = gen_hug(10_000, 30, k=1, initial=initial)
        r = run_with_trace(vals, 30, initial=initial)
        summary = {k2: r[k2] for k2 in ("n_in", "accepted", "prot", "prot_pct", "path", "net")}
        out["initial_states"].append({"initial": initial, "th": 30, **summary})

    return out


def phase7_attack_sequences() -> Dict[str, Any]:
    """2. Attack sequences with event-by-event traces (sampled)."""
    out: Dict[str, Any] = {
        "meta": {"phase": "7b", "title": "attack sequences with traces", "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
        "attacks": [],
    }
    th = 25
    n = 2000  # keep traces manageable; long runs already in surface

    attacks = [
        ("slow_drift", gen_hug(n, th, k=1, alternate=False)),
        ("chatter", gen_chatter(n, th - 1)),
        ("boundary_camp", gen_boundary_camp(n, th)),
        ("alternating", gen_hug(n, th, k=1, alternate=True)),
        ("contradictory", gen_contradictory(n, th)),
        ("quiet_then_step", gen_quiet_then_step(200, n - 200, th)),
        ("combo_drift_chatter", gen_combo_drift_chatter(n, th)),
        ("random_avoid_seed42", gen_random_avoid(n, th, seed=42)),
        ("random_avoid_seed99", gen_random_avoid(n, th, seed=99)),
    ]

    for name, vals in attacks:
        r = run_with_trace(vals, th)
        # Keep full events for these (n=2000 is fine)
        out["attacks"].append({
            "name": name,
            "th": th,
            "n": n,
            "summary": {
                "prot": r["prot"],
                "prot_pct": r["prot_pct"],
                "path": r["path"],
                "net": r["net"],
                "accepted": r["accepted"],
            },
            "events_head": r["events"][:20],   # first 20
            "events_tail": r["events"][-10:],  # last 10
            "events_len": len(r["events"]),
            # store a compact fingerprint of the whole sequence for provenance
            "seq_fp": hashlib.sha256(
                json.dumps([e["input"] for e in r["events"][::50]], separators=(",", ":")).encode()
            ).hexdigest()[:16],
        })
    return out


def phase7_policy_ablation() -> Dict[str, Any]:
    """3. Smallest external policy — one control at a time."""
    out: Dict[str, Any] = {
        "meta": {"phase": "7c", "title": "policy ablation one-at-a-time", "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
        "configs": [],
        "results": [],
    }

    th = 40
    n = 5000
    # Demonstrated bypasses
    bypasses = {
        "slow_drift": gen_hug(n, th, k=1, alternate=False),
        "chatter": gen_chatter(n, th - 1),
        "boundary_camp": gen_boundary_camp(n, th),
        "combo": gen_combo_drift_chatter(n, th),
    }
    # Legitimate patterns (O(n) construction)
    def _small_walk(nn, seed=7):
        rng = random.Random(seed)
        v, out = 0, []
        for _ in range(nn):
            v += rng.randint(-3, 3)
            out.append(v)
        return out
    legit = {
        "small_walk": _small_walk(n),
        "gentle_ramp": list(range(1, n + 1)),  # step=1
    }

    configs = [
        ("bare", {}),
        ("authority_20", {"authority_delta": 20}),
        ("cum_500", {"cum_disp_limit": 500}),
        ("rate_100_w10", {"rate_limit": 100, "rate_window": 10}),
        ("chatter_6_w20", {"chatter_limit": 6, "chatter_window": 20}),
        ("auth20+cum500", {"authority_delta": 20, "cum_disp_limit": 500}),
    ]
    out["configs"] = [{"name": n, "params": p} for n, p in configs]

    for cname, params in configs:
        for bname, vals in {**bypasses, **legit}.items():
            pol = Policy(**params) if params else None
            def filt(v, last, p=pol):
                if p is None:
                    return v, "pass"
                return p.filter(v, last)
            r = run_with_trace(vals, th, policy=filt if pol else None)
            out["results"].append({
                "config": cname,
                "pattern": bname,
                "is_bypass": bname in bypasses,
                "prot_pct": r["prot_pct"],
                "path": r["path"],
                "net": r["net"],
                "accepted": r["accepted"],
                "rejected": r["rejected"],
                "rejected_pct": 100.0 * r["rejected"] / max(1, r["n_in"]),
                "block_reasons": r["block_reasons"],
            })
    return out


def phase7_redteam() -> Dict[str, Any]:
    """4. Red-team: same generator vs bare kernel vs policy-wrapped."""
    out: Dict[str, Any] = {
        "meta": {"phase": "7d", "title": "red-team bare vs policy", "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
        "comparisons": [],
    }
    th = 40
    n = 8000
    policy = Policy(authority_delta=20, cum_disp_limit=500)

    generators = [
        ("slow_drift", lambda: gen_hug(n, th, k=1)),
        ("chatter", lambda: gen_chatter(n, th - 1)),
        ("boundary_camp", lambda: gen_boundary_camp(n, th)),
        ("combo", lambda: gen_combo_drift_chatter(n, th)),
        ("random_avoid", lambda: gen_random_avoid(n, th, seed=123)),
        ("legit_small", lambda: _gen_small(n, seed=11)),
        ("legit_ramp", lambda: list(range(0, n * 2, 2))),  # step 2
    ]

    for name, gen in generators:
        vals = gen()
        bare = run_with_trace(vals, th)
        pol_r = run_with_trace(vals, th, policy=lambda v, last, p=policy: p.filter(v, last))
        out["comparisons"].append({
            "attack": name,
            "bare": {
                "prot_pct": bare["prot_pct"],
                "path": bare["path"],
                "net": bare["net"],
                "accepted": bare["accepted"],
            },
            "policy": {
                "prot_pct": pol_r["prot_pct"],
                "path": pol_r["path"],
                "net": pol_r["net"],
                "accepted": pol_r["accepted"],
                "rejected": pol_r["rejected"],
                "rejected_pct": 100.0 * pol_r["rejected"] / max(1, pol_r["n_in"]),
                "block_reasons": pol_r["block_reasons"],
            },
            "attack_caught": pol_r["rejected"] > 0 and name.startswith(("slow", "chatter", "boundary", "combo", "random")),
            "legit_rejected": pol_r["rejected"] > 0 and name.startswith("legit"),
        })
    return out


def main():
    results_dir = Path(__file__).resolve().parents[1] / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    reports_dir = Path(__file__).resolve().parents[1] / "reports"

    print("=== Phase 7a: surface ===")
    surface = phase7_surface()
    p = results_dir / "phase7a_threshold_surface.json"
    p.write_text(json.dumps(surface, indent=2))
    print(f"  wrote {p}  grid={len(surface['grid'])} long={len(surface['long_streams'])}")

    print("=== Phase 7b: attack sequences ===")
    attacks = phase7_attack_sequences()
    p = results_dir / "phase7b_attack_sequences.json"
    # events are large; write full
    p.write_text(json.dumps(attacks, indent=2))
    print(f"  wrote {p}  attacks={len(attacks['attacks'])}")

    print("=== Phase 7c: policy ablation ===")
    ablation = phase7_policy_ablation()
    p = results_dir / "phase7c_policy_ablation.json"
    p.write_text(json.dumps(ablation, indent=2))
    print(f"  wrote {p}")

    print("=== Phase 7d: red-team ===")
    red = phase7_redteam()
    p = results_dir / "phase7d_redteam.json"
    p.write_text(json.dumps(red, indent=2))
    print(f"  wrote {p}")

    # Compact console summary for research question
    print("\n========== RESEARCH QUESTION SUMMARY ==========")
    zero = [g for g in surface["grid"] if g["step"] > 0 and g["prot"] == 0]
    print(f"1. Harmful trajectory under contract: {len(zero)}/{len(surface['grid'])} sub-threshold grid cells = 0% PROTECT")
    for ls in surface["long_streams"]:
        print(f"   long {ls['mode']} th={ls['th']} n={ls['n_in']}: prot%={ls['prot_pct']:.1f} path={ls['path']} net={ls['net']}")

    print("\n2/3. Minimal policy that closes demonstrated holes:")
    for row in ablation["results"]:
        if row["config"] == "auth20+cum500" and row["is_bypass"]:
            print(f"   {row['pattern']}: rejected={row['rejected_pct']:.1f}% path={row['path']} reasons={row['block_reasons']}")

    print("\n4. Tradeoffs (legit under auth20+cum500):")
    for row in ablation["results"]:
        if row["config"] == "auth20+cum500" and not row["is_bypass"]:
            print(f"   {row['pattern']}: rejected={row['rejected_pct']:.1f}%")

    print("\n5/6. Red-team (bare vs auth+cum):")
    for c in red["comparisons"]:
        print(f"   {c['attack']:16s} bare_path={c['bare']['path']:8d}  pol_rej%={c['policy']['rejected_pct']:5.1f}  caught={c['attack_caught']} legit_rej={c['legit_rejected']}")

    # Write a short phase-7 report section
    report_path = reports_dir / "PHASE7_FINDINGS.md"
    report_path.write_text(_make_report(surface, attacks, ablation, red))
    print(f"\nReport: {report_path}")


def _make_report(surface, attacks, ablation, red) -> str:
    lines = [
        "# Phase 7 Findings — Threshold Surface, Attack Sequences, Policy, Red-Team",
        "",
        f"**Generated:** {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}",
        "**Label:** RECONSTRUCTED / NEW experiments in Grok sandbox",
        "**Constraint:** Production kernel untouched",
        "",
        "## 1. How much harmful trajectory is permitted while every event stays compliant?",
        "",
        "Every grid cell with step = threshold−k (k≥1) yields **0% PROTECT**.",
        "Long streams (100k events, th=20, Δ=19) produce path length 1.9M and net ±1.9M with zero protections.",
        "Initial state does not matter; the contract is memoryless except for last_value.",
        "",
        "## 2–3. Minimum additional policy and which holes it closes",
        "",
        "| Control | Closes slow_drift | Closes chatter/camp | FP on small walk |",
        "|---------|-------------------|---------------------|------------------|",
        "| authority_delta=20 | Yes (steps >20 blocked) | Partial | Low |",
        "| cum_disp_limit=500 | Yes (unbounded drift) | No | Low if limit >> normal |",
        "| rate limit | Partial | Partial | Low if tuned |",
        "| chatter limit | No | Partial | **High** |",
        "| **auth + cum (minimal set)** | **Yes** | **Partial** | **Low on small walks** |",
        "",
        "Chatter that stays inside the authority band still passes; residual in-band attacks remain.",
        "",
        "## 4. Tradeoffs introduced",
        "",
        "- Origin dependence: long honest ramps eventually hit cum_disp unless origin is updated.",
        "- Authority floor: too tight rejects legitimate fast moves.",
        "- No semantic understanding of intent or contradiction.",
        "- Latency/memory: O(window) history for rate/chatter; negligible for auth+cum alone.",
        "",
        "## 5. Attack classes still outside scope",
        "",
        "Anything that respects both numeric envelopes (authority + cumulative displacement from a fixed origin).",
        "Goal appropriateness, contradiction between successive high-confidence recommendations, world-model violations.",
        "",
        "## 6. Controllability when adversary understands the boundary",
        "",
        "An adversary that knows (threshold, authority, cum_limit) can still produce non-trivial path length",
        "and chatter inside the box. The architecture remains a numeric interlock, not a semantic guard.",
        "It stops blunt/incompetent large moves; it does not stop a capable optimizer that respects the envelopes.",
        "",
        "## Evidence",
        "",
        "- results/phase7a_threshold_surface.json",
        "- results/phase7b_attack_sequences.json (event traces head/tail + seq fingerprints)",
        "- results/phase7c_policy_ablation.json",
        "- results/phase7d_redteam.json",
        "",
        "C adversarial harness previously confirmed no contract violations under long adversarial input.",
    ]
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    main()
