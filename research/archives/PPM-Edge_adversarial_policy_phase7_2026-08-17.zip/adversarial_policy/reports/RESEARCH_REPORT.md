# Research Report: PPM-Edge Bypass Surface & Minimal Policy Layer

**Date:** 2026-08-16 → 2026-08-17 (phases 5–6 added)  
**Scope:** Isolated experimental layer only. Production PPM-Edge kernel untouched.  
**Label:** All generators, harnesses, results, and this report are **RECONSTRUCTED** in the Grok sandbox.

## Executive summary

1. The kernel is deterministic and contract-correct: sequences of valid inputs cannot force an illegal (contract-violating) outcome.
2. An adversary that never emits CRITICAL and keeps `|Δ| ≤ threshold−1` achieves **0 % PROTECT** for arbitrary length, producing unbounded path length and net displacement.
3. A minimal external policy of `authority_delta` + `cum_disp_limit` closes the demonstrated slow-drift and large-hug holes with low false-positive rate on small legitimate walks.
4. Residual in-band attacks remain inside those envelopes; chatter limits introduce high false positives; long legitimate setpoint moves expose origin dependence.

## 1. Bypass surface (phases 1–2, 5)

Under the existing contract (`protected = delta >= threshold OR CRITICAL`):

| Pattern | PROTECT rate | Scale demonstrated |
|---------|--------------|--------------------|
| Δ = threshold − 1 (hug) | **0 %** | 50 k steps, path 950 k (th=20) |
| Unidirectional slow drift | **0 %** | net displacement = n × (th−1) |
| Alternating / chatter sub-threshold | **0 %** | tens of thousands of reversals |
| Randomized avoid-PROTECT | **0 %** on many seeds | path ~ tens–hundreds of k |

Phase-5 grid (106 points): every (th, k) with k ≥ 1 and step = th−k > 0 yields 0 % protection for both unidirectional and alternating modes. Only k = 0 (exact threshold) yields 100 % protection.

## 2. Minimal policy layer (phases 3–4, 6)

Mechanisms evaluated externally (kernel unchanged):

| Mechanism | Closes slow_drift | Closes hug/chatter | FP on legit small walk |
|-----------|-------------------|--------------------|------------------------|
| authority_delta | Yes | Partial (blocks > auth) | Low (if auth ≥ typical step) |
| cum_disp_limit | Yes | No (returns to origin) | Low if limit ≫ normal range |
| rate limit | Yes | Partial | Low if tuned |
| chatter limit | No | Partial | **High** |

**Minimal effective set:** `authority_delta` + `cum_disp_limit`.

Phase-6 quantification (threshold=50, auth=20, cum=500):

- Legitimate small_walk (Δ≤3): 0 % rejected under auth+cum.
- Legitimate long setpoint ramp / slow ramp: eventually blocked by cum_disp (origin dependence) — expected; origin must be updated by a higher authority for honest long moves.
- Chatter limit (≥8 reversals in window): ~96 % rejection on ordinary small walks → unusable without careful tuning.
- Residual adversary that stays inside both envelopes still obtains substantial path length (drift/random) and non-zero accepted steps (chatter partially reduced by the hard auth cap).

## 3. New failure modes introduced by the policy layer

1. **Origin dependence** — long honest setpoint changes are blocked unless the origin is advanced.
2. **Authority tuning tradeoff** — too tight rejects legitimate fast moves; too loose re-opens slow drift inside the band.
3. **No semantics** — the layer cannot detect contradiction, wrong goal, or manipulative intent.
4. **Residual in-band attack** — anything that respects both numeric envelopes still passes the gate.

## 4. What remains outside PPM-Edge scope

Intent, contradiction detection, world models, task constraints, goal appropriateness — anything that cannot be reduced to the numeric triple `(value, threshold, priority)` or simple functions of recent delta history.

PPM-Edge is a fast, deterministic numeric interlock, not a planner or value-alignment system.

## 5. Implications

Useful as a last numeric safety interlock that stops gross / incompetent large moves when the threshold matches the physical/authority envelope. It does **not** stop a capable adversarial or simply optimizing AI that respects the numeric envelope while still being wrong for the mission.

## 6. Reproduction (exact)

```bash
cd research/adversarial_policy

# Pure-Python reference + phases 5–6
python3 generators/phase5_threshold_surface.py
python3 generators/phase6_residual_and_policy.py

# Earlier generators
python3 generators/stress_pure_python.py
python3 generators/multi_seed_differential.py
python3 generators/threshold_hugging_vectors.py --threshold 25 --k 1 --n 5000

# C harness (no contract violations)
cd harness/c_harness
gcc -O2 -o /tmp/ppm_adv adversarial_main.c Ppm_edge.c -I.
/tmp/ppm_adv
```

## 7. Artifact hashes (sha256[:16]) at packaging time

See `PROVENANCE.md` for the full table. Key results:

- phase5_threshold_surface.json → `4ea1b7187cdcb5c9`
- phase6_residual_policy.json → `df5808ad3a34dea5`
- ppm_ref.py → `fc705bb92083e5a0`
- Ppm_edge.c (harness copy) → `ba10cee33d6efc1e`
