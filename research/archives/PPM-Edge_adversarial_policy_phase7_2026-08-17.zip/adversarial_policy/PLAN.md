# Experimental Plan — Adversarial Policy Layer

**Status:** Phases 1–6 complete in Grok sandbox  
**Constraint:** Do not modify production PPM-Edge implementation.

## Completed (verified)

- [x] Determinism / multi-seed differential (Python)
- [x] Long adversarial sequences (Python + standalone C)
- [x] Three-way agreement (Python reference, C kernel, sandbox CPython extension) on in-contract behavior
- [x] Threshold-hugging bypass demonstrated (Δ = th−1 → 0% PROTECT)
- [x] Cumulative unidirectional displacement bypass
- [x] Chatter / rapid oscillation bypass
- [x] Minimal external policy ablation (authority_delta, cum_disp_limit, rate, chatter)
- [x] Red-team bare vs policy on demonstrated attacks
- [x] V1 correctness gates re-run / C adversarial harness ALL PASS
- [x] Phase 5 — deeper threshold-hugging surface map (grid + long runs + residual in-band)
- [x] Phase 6 — residual in-band quantification + refined policy ablation + FP rates on legit traffic

## Next candidate phases (not yet executed)

### 7. Origin-update protocol
- Define a privileged “set origin” operation that a higher authority can call
- Measure how often origin must be advanced for realistic long-horizon tasks
- Ensure adversary cannot call it

### 8. Semantic / contradiction layer (out of kernel scope)
- Explicitly document that contradiction, goal appropriateness, and world-model checks belong outside PPM-Edge
- Prototype a thin advisory wrapper that only logs / scores, never blocks, to keep the numeric gate pure

### 9. Latency & resource characterization
- Cycle counts / wall time for pure-Python vs C vs policy-wrapped paths
- Memory footprint of history windows used by rate/chatter controls

### 10. Hygiene & packaging
- Keep production source untouched
- Maintain PROVENANCE.md and per-artifact hashes
- Single downloadable archive for owner import
