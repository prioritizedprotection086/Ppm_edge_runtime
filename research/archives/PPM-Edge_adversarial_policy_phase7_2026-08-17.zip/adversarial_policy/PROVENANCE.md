# Provenance (updated after Phase 7)
## Phase 7 artifact hashes (sha256[:16])
| Path | sha256[:16] |
|------|-------------|
| GITHUB_IMPORT.md | d8ccad00c8630c7f |
| PLAN.md | 29af88e3eb59abc7 |
| PROVENANCE.md | 800c182ba4f54c46 |
| README.md | 3160cf9e25f7a0d3 |
| generators/ai_adversarial_boundary.py | baf1da8370a4b3da |
| generators/multi_seed_differential.py | cb9ab2aae6cfa10a |
| generators/phase5_threshold_surface.py | bcdc9e9a705169d8 |
| generators/phase6_residual_and_policy.py | cc49822defd0d19e |
| generators/phase7_full_surface_and_redteam.py | 8684ebb505e60186 |
| generators/stress_pure_python.py | 67a9c383f05a1294 |
| generators/threshold_hugging_vectors.py | cd25aaab72bffc93 |
| harness/Ppm_edge.c | ba10cee33d6efc1e |
| harness/Ppm_edge.h | 5e78e7ecd5ec073e |
| harness/c_harness/Ppm_edge.c | ba10cee33d6efc1e |
| harness/c_harness/Ppm_edge.h | 5e78e7ecd5ec073e |
| harness/c_harness/adversarial_main.c | da13470bc5d92a8b |
| harness/ppm_ext.c | 6258bc1a55dd1240 |
| harness/ppm_ref.py | fc705bb92083e5a0 |
| harness/setup.py | a6b963f74613d477 |
| harness/three_way_compare.py | f6ad604156b3a306 |
| policy_layers/min_policy.py | 82153d3ed962ef0d |
| reports/PHASE7_FINDINGS.md | 002b50228538d825 |
| reports/RESEARCH_REPORT.md | 52742123789bc51a |
| results/phase1_bypass_surface.json | 71d07b7325edd7bd |
| results/phase2_adversarial.json | 455925ed193c2b72 |
| results/phase3_policy_ablation.json | f091613e085e749c |
| results/phase4_redteam.json | 97c0c60e11096291 |
| results/phase5_threshold_surface.json | 4ea1b7187cdcb5c9 |
| results/phase6_residual_policy.json | df5808ad3a34dea5 |
| results/phase7a_threshold_surface.json | 6ee949049e16ca1e |
| results/phase7b_attack_sequences.json | 268f3879c92c156c |
| results/phase7c_policy_ablation.json | f77ff6574a176872 |
| results/phase7d_redteam.json | 063f235d1bd26e8d |
| results/threshold_hugging_surface.json | 77f125a88ac33d3a |

**Label:** All RECONSTRUCTED. Production kernel never modified.
