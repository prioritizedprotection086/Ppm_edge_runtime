# GITHUB_IMPORT.md — Where each file belongs

Import this entire directory tree under the repository root as:

```
research/adversarial_policy/
```

## Recommended layout after import

```
Ppm_edge_runtime/                          # repo root
├── Src/ ...                               # PRODUCTION — do not touch
├── src/ ...                               # PRODUCTION — do not touch
├── research/
│   └── adversarial_policy/                # ← place the contents of this archive here
│       ├── README.md
│       ├── PLAN.md
│       ├── PROVENANCE.md
│       ├── GITHUB_IMPORT.md               # this file
│       ├── generators/
│       │   ├── ai_adversarial_boundary.py
│       │   ├── multi_seed_differential.py
│       │   ├── stress_pure_python.py
│       │   ├── threshold_hugging_vectors.py
│       │   ├── phase5_threshold_surface.py
│       │   └── phase6_residual_and_policy.py
│       ├── harness/
│       │   ├── Ppm_edge.c                 # copy of production kernel for isolated tests
│       │   ├── Ppm_edge.h
│       │   ├── ppm_ref.py                 # pure-Python reference
│       │   ├── ppm_ext.c / setup.py       # optional CPython extension
│       │   ├── three_way_compare.py
│       │   └── c_harness/
│       │       ├── Ppm_edge.c
│       │       ├── Ppm_edge.h
│       │       └── adversarial_main.c
│       ├── policy_layers/
│       │   └── min_policy.py
│       ├── results/
│       │   ├── phase1_bypass_surface.json
│       │   ├── phase2_adversarial.json
│       │   ├── phase3_policy_ablation.json
│       │   ├── phase4_redteam.json
│       │   ├── phase5_threshold_surface.json
│       │   ├── phase6_residual_policy.json
│       │   └── threshold_hugging_surface.json
│       └── reports/
│           └── RESEARCH_REPORT.md
```

## Suggested branch

```bash
git checkout -b research/adversarial-policy-layer
# copy the tree into research/adversarial_policy/
git add research/adversarial_policy/
git commit -m "Add isolated adversarial policy-layer research artifacts (RECONSTRUCTED)"
```

## What must NOT be changed

- Any file under `Src/`, `src/`, production tests, or existing CI that exercises the production kernel.
- Do not treat the harness copies of `Ppm_edge.c` / `.h` as the production sources; they are frozen snapshots for differential testing only.

## Optional CI

If desired, a research workflow can be added under `.github/workflows/research.yml` that only runs the generators and C harness inside `research/adversarial_policy/`. It must not gate production merges.
