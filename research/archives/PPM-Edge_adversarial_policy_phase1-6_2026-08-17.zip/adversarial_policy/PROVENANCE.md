# Provenance

## Base repository state (reference only — not modified)
- **Remote:** https://github.com/prioritizedprotection086/Ppm_edge_runtime
- **Base commit (branch point):** `38d27b888b6719e2b37bbe2df7391d600de91243` — "Add files via upload"
- **Intended branch name:** `research/adversarial-policy-layer` (to be created by repo owner)
- **Production tree:** unchanged (only additions under `research/`)

## Source file hashes (sha256[:16]) — packaging time 2026-08-17

| Path | sha256[:16] |
|------|-------------|
| harness/Ppm_edge.c | ba10cee33d6efc1e |
| harness/Ppm_edge.h | 5e78e7ecd5ec073e |
| harness/ppm_ref.py | fc705bb92083e5a0 |
| harness/c_harness/adversarial_main.c | da13470bc5d92a8b |
| generators/phase5_threshold_surface.py | bcdc9e9a705169d8 |
| generators/phase6_residual_and_policy.py | cc49822defd0d19e |
| results/phase5_threshold_surface.json | 4ea1b7187cdcb5c9 |
| results/phase6_residual_policy.json | df5808ad3a34dea5 |
| results/phase1_bypass_surface.json | 71d07b7325edd7bd |
| results/phase2_adversarial.json | 455925ed193c2b72 |
| results/phase3_policy_ablation.json | f091613e085e749c |
| results/phase4_redteam.json | 97c0c60e11096291 |
| policy_layers/min_policy.py | 82153d3ed962ef0d |
| reports/RESEARCH_REPORT.md | (see file) |

## Environment
- Platform: Linux sandbox
- Python: 3.12.x
- gcc: x86_64-linux-gnu-gcc
- No network writes; no GitHub push attempted from this session after permission confirmation

## Experiments executed
| Experiment | Result | Artifact |
|------------|--------|----------|
| V1-style contract gates (C) | ALL PASS | harness/c_harness |
| Phase 1–4 (prior session) | completed | results/phase[1-4]_*.json |
| Phase 5 threshold surface | completed | results/phase5_threshold_surface.json |
| Phase 6 residual + policy ablation | completed | results/phase6_residual_policy.json |
| Pure-Python reference vs C semantics | match | harness/ppm_ref.py |

## Labeling
All research code/results here are **RECONSTRUCTED** (Grok sandbox), not original Claude V2/V2.1 artifacts. Production sources were never modified.
